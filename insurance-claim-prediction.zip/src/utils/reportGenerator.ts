import jsPDF from 'jspdf';
import { DatasetStats, PredictionResult } from '../types';
import { TrainingContext } from '../ml/modelTraining';
import {
  analyzeByAgeGroup,
  analyzeByPolicyType,
  analyzeByVehicleType,
  analyzeByPreviousClaims,
  analyzeByAccidentHistory,
  analyzePremiumDistribution,
} from './insuranceAnalysis';
import { generateDynamicInsights } from './insights';

export async function generatePdfReport(
  stats: DatasetStats,
  trainingContext: TrainingContext,
  latestPrediction: PredictionResult | null
): Promise<void> {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 16;
  const contentWidth = pageWidth - margin * 2;

  const records = [...trainingContext.trainRecords, ...trainingContext.testRecords];
  const insights = generateDynamicInsights(stats, trainingContext);

  const primaryColor = [30, 41, 59]; // slate-800
  const accentColor = [14, 116, 144]; // cyan-700
  const mutedColor = [100, 116, 139]; // slate-500
  const lightBg = [248, 250, 252]; // slate-50

  function drawHeader(title: string, subtitle: string, pageNum: number) {
    doc.setFillColor(lightBg[0], lightBg[1], lightBg[2]);
    doc.rect(0, 0, pageWidth, 28, 'F');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(16);
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.text(title, margin, 12);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.setTextColor(mutedColor[0], mutedColor[1], mutedColor[2]);
    doc.text(subtitle, margin, 18);

    doc.text(`Page ${pageNum} of 5`, pageWidth - margin - 20, 15);

    doc.setDrawColor(226, 232, 240);
    doc.setLineWidth(0.5);
    doc.line(margin, 28, pageWidth - margin, 28);
  }

  function drawFooter() {
    doc.setDrawColor(226, 232, 240);
    doc.setLineWidth(0.5);
    doc.line(margin, pageHeight - 14, pageWidth - margin, pageHeight - 14);

    doc.setFont('helvetica', 'italic');
    doc.setFontSize(7.5);
    doc.setTextColor(mutedColor[0], mutedColor[1], mutedColor[2]);
    doc.text(
      'Machine Learning Claim Likelihood Analytics • For Analytical Decision Support Only • Not an Underwriting Determination',
      margin,
      pageHeight - 8
    );
    doc.text(new Date().toLocaleDateString(), pageWidth - margin - 22, pageHeight - 8);
  }

  // ==========================================
  // PAGE 1: DATASET OVERVIEW
  // ==========================================
  drawHeader('Insurance Claim Analytics Report', 'Section 1: Portfolio & Dataset Overview', 1);

  let y = 38;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(13);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text('1. Executive Portfolio Summary', margin, y);

  y += 7;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9.5);
  doc.setTextColor(mutedColor[0], mutedColor[1], mutedColor[2]);
  doc.text(
    'This report compiles empirical machine learning analytics and claim probability classifications derived from',
    margin,
    y
  );
  y += 5;
  doc.text(
    `the historical insurance dataset containing ${stats.totalPolicies.toLocaleString()} validated policy records.`,
    margin,
    y
  );

  y += 10;
  // KPI Grid Cards
  const kpis = [
    { label: 'Total Policies', value: stats.totalPolicies.toLocaleString(), sub: 'Validated sample size' },
    { label: 'Claim Incidents', value: stats.totalClaims.toLocaleString(), sub: `${stats.claimRate}% portfolio claim rate` },
    { label: 'No-Claim Policies', value: stats.totalNoClaims.toLocaleString(), sub: `${stats.noClaimRate}% safe policies` },
    { label: 'Avg Annual Premium', value: `$${stats.avgPremium.toLocaleString()}`, sub: 'Across all vehicles' },
    { label: 'Avg Coverage Amount', value: `$${stats.avgCoverage.toLocaleString()}`, sub: 'Policy face value' },
    { label: 'Avg Customer Age', value: `${stats.avgCustomerAge} yrs`, sub: 'Distribution mean' },
    { label: 'Avg Policy Tenure', value: `${stats.avgPolicyTenure} yrs`, sub: 'Customer retention' },
    { label: 'Avg Driving Experience', value: `${stats.avgDrivingExperience} yrs`, sub: 'Recorded road history' },
  ];

  const colWidth = (contentWidth - 6) / 2;
  const cardHeight = 16;

  kpis.forEach((kpi, idx) => {
    const col = idx % 2;
    const row = Math.floor(idx / 2);
    const cx = margin + col * (colWidth + 6);
    const cy = y + row * (cardHeight + 4);

    doc.setFillColor(248, 250, 252);
    doc.roundedRect(cx, cy, colWidth, cardHeight, 2, 2, 'F');
    doc.setDrawColor(226, 232, 240);
    doc.roundedRect(cx, cy, colWidth, cardHeight, 2, 2, 'S');

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(mutedColor[0], mutedColor[1], mutedColor[2]);
    doc.text(kpi.label, cx + 4, cy + 5);

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.text(kpi.value, cx + 4, cy + 10.5);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7);
    doc.setTextColor(mutedColor[0], mutedColor[1], mutedColor[2]);
    doc.text(kpi.sub, cx + 4, cy + 14);
  });

  y += 4 * (cardHeight + 4) + 8;

  // Data hygiene & split info
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text('2. Dataset Preprocessing & Partitioning', margin, y);

  y += 7;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(mutedColor[0], mutedColor[1], mutedColor[2]);

  const prepDetails = [
    `• Training Partition: ${trainingContext.trainSize} records (80.0%) using stratified class sampling`,
    `• Testing Partition: ${trainingContext.testSize} records (20.0%) reserved strictly for evaluation`,
    `• Total Feature Space: ${trainingContext.numFeatures} engineered & encoded variables (numeric, one-hot, and derived)`,
    `• Imputation Protocol: Median imputation for continuous metrics, frequency-mode for categories`,
    `• Standard Normalization: Z-score transformation ($x - \\mu) / \\sigma$ applied to continuous variables`,
  ];
  prepDetails.forEach((line) => {
    doc.text(line, margin, y);
    y += 5.5;
  });

  drawFooter();

  // ==========================================
  // PAGE 2: INSURANCE ANALYSIS
  // ==========================================
  doc.addPage();
  drawHeader('Insurance Claim Analytics Report', 'Section 2: Empirical Claim Pattern Analysis', 2);

  y = 36;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text('1. Claim Frequency by Policy Type', margin, y);

  y += 6;
  const policyTypes = analyzeByPolicyType(records);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setFillColor(241, 245, 249);
  doc.rect(margin, y, contentWidth, 6, 'F');
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text('Policy Type', margin + 4, y + 4.2);
  doc.text('Policies', margin + 50, y + 4.2);
  doc.text('Claims', margin + 80, y + 4.2);
  doc.text('Claim Rate', margin + 110, y + 4.2);
  doc.text('Avg Premium', margin + 145, y + 4.2);

  y += 6;
  doc.setFont('helvetica', 'normal');
  policyTypes.forEach((pt) => {
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.text(pt.name, margin + 4, y + 4.2);
    doc.text(pt.total.toString(), margin + 50, y + 4.2);
    doc.text(pt.claims.toString(), margin + 80, y + 4.2);
    doc.text(`${pt.claimRate}%`, margin + 110, y + 4.2);
    doc.text(`$${pt.avgPremium.toLocaleString()}`, margin + 145, y + 4.2);
    y += 5.5;
  });

  y += 6;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text('2. Claim Frequency by Customer Age Group', margin, y);

  y += 6;
  const ageGroups = analyzeByAgeGroup(records);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setFillColor(241, 245, 249);
  doc.rect(margin, y, contentWidth, 6, 'F');
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text('Age Group', margin + 4, y + 4.2);
  doc.text('Policies', margin + 50, y + 4.2);
  doc.text('Claims', margin + 80, y + 4.2);
  doc.text('Claim Rate', margin + 110, y + 4.2);
  doc.text('Avg Premium', margin + 145, y + 4.2);

  y += 6;
  doc.setFont('helvetica', 'normal');
  ageGroups.forEach((ag) => {
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.text(ag.name, margin + 4, y + 4.2);
    doc.text(ag.total.toString(), margin + 50, y + 4.2);
    doc.text(ag.claims.toString(), margin + 80, y + 4.2);
    doc.text(`${ag.claimRate}%`, margin + 110, y + 4.2);
    doc.text(`$${ag.avgPremium.toLocaleString()}`, margin + 145, y + 4.2);
    y += 5.5;
  });

  y += 6;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text('3. Historical Claims & Accident Associations', margin, y);

  y += 6;
  const prevClaims = analyzeByPreviousClaims(records);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setFillColor(241, 245, 249);
  doc.rect(margin, y, contentWidth, 6, 'F');
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text('Previous Claims', margin + 4, y + 4.2);
  doc.text('Policies', margin + 50, y + 4.2);
  doc.text('Claims', margin + 80, y + 4.2);
  doc.text('Observed Claim Rate', margin + 110, y + 4.2);

  y += 6;
  doc.setFont('helvetica', 'normal');
  prevClaims.forEach((pc) => {
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.text(pc.name, margin + 4, y + 4.2);
    doc.text(pc.total.toString(), margin + 50, y + 4.2);
    doc.text(pc.claims.toString(), margin + 80, y + 4.2);
    doc.text(`${pc.claimRate}%`, margin + 110, y + 4.2);
    y += 5.5;
  });

  drawFooter();

  // ==========================================
  // PAGE 3: CLAIM PREDICTION
  // ==========================================
  doc.addPage();
  drawHeader('Insurance Claim Analytics Report', 'Section 3: Subject Policy Likelihood Estimate', 3);

  y = 36;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text('1. Evaluated Policy & Customer Profile', margin, y);

  y += 6;
  if (latestPrediction) {
    const inp = latestPrediction.input;

    const fields = [
      { label: 'Customer Age', val: `${inp.customer_age} years` },
      { label: 'Gender', val: inp.gender },
      { label: 'Annual Income', val: `$${inp.annual_income.toLocaleString()}` },
      { label: 'Driving Experience', val: `${inp.driving_experience} years` },
      { label: 'Policy Type', val: inp.policy_type },
      { label: 'Policy Tenure', val: `${inp.policy_tenure} years` },
      { label: 'Annual Premium', val: `$${inp.premium_amount.toLocaleString()}` },
      { label: 'Coverage Amount', val: `$${inp.coverage_amount.toLocaleString()}` },
      { label: 'Vehicle Type', val: inp.vehicle_type },
      { label: 'Vehicle Age', val: `${inp.vehicle_age} years` },
      { label: 'Vehicle Usage', val: inp.vehicle_usage },
      { label: 'Previous Claims', val: inp.previous_claims.toString() },
      { label: 'Accident History', val: inp.accident_history },
      { label: 'Claim History', val: inp.claim_history },
    ];

    const fWidth = (contentWidth - 6) / 2;
    fields.forEach((f, i) => {
      const col = i % 2;
      const row = Math.floor(i / 2);
      const fx = margin + col * (fWidth + 6);
      const fy = y + row * 8;

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8);
      doc.setTextColor(mutedColor[0], mutedColor[1], mutedColor[2]);
      doc.text(`${f.label}:`, fx, fy);

      doc.setFont('helvetica', 'normal');
      doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
      doc.text(f.val, fx + 36, fy);
    });

    y += Math.ceil(fields.length / 2) * 8 + 8;

    // Prediction Outcome Box
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.text('2. Machine Learning Classification Outcome', margin, y);

    y += 6;
    const isClaim = latestPrediction.predictedClass === 1;
    doc.setFillColor(isClaim ? 254 : 240, isClaim ? 242 : 253, isClaim ? 242 : 244);
    doc.roundedRect(margin, y, contentWidth, 34, 3, 3, 'F');
    doc.setDrawColor(isClaim ? 239 : 34, isClaim ? 68 : 197, isClaim ? 68 : 94);
    doc.roundedRect(margin, y, contentWidth, 34, 3, 3, 'S');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(14);
    doc.setTextColor(isClaim ? 185 : 21, isClaim ? 28 : 128, isClaim ? 28 : 61);
    doc.text(
      isClaim ? 'Result: Likely to Result in a Claim' : 'Result: Likely No Claim',
      margin + 6,
      y + 10
    );

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9.5);
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.text(
      `Claim Probability: ${(latestPrediction.claimProbability * 100).toFixed(1)}%   •   No-Claim Probability: ${(latestPrediction.noClaimProbability * 100).toFixed(1)}%`,
      margin + 6,
      y + 18
    );
    doc.text(
      `Algorithm: ${latestPrediction.modelUsed}   •   Decision Threshold: ${latestPrediction.threshold}   •   Confidence: ${(latestPrediction.confidence * 100).toFixed(1)}%`,
      margin + 6,
      y + 25
    );

    y += 42;

    if (latestPrediction.topFactors.length > 0) {
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(10);
      doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
      doc.text('3. Key Individual Risk Indicators', margin, y);

      y += 6;
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8.5);
      latestPrediction.topFactors.forEach((tf) => {
        doc.setTextColor(tf.impact === 'increases risk' ? 185 : 21, tf.impact === 'increases risk' ? 28 : 128, 28);
        doc.text(`• [${tf.impact.toUpperCase()}] ${tf.factor}: `, margin + 4, y);
        doc.setTextColor(mutedColor[0], mutedColor[1], mutedColor[2]);
        doc.text(tf.description, margin + 46, y);
        y += 5.5;
      });
    }
  } else {
    doc.setFont('helvetica', 'italic');
    doc.setFontSize(9.5);
    doc.setTextColor(mutedColor[0], mutedColor[1], mutedColor[2]);
    doc.text('No active individual prediction was submitted during this session.', margin, y);
    y += 8;
    doc.text('Users can enter custom policyholder parameters on the Claim Predictor tab.', margin, y);
  }

  drawFooter();

  // ==========================================
  // PAGE 4: MODEL PERFORMANCE
  // ==========================================
  doc.addPage();
  drawHeader('Insurance Claim Analytics Report', 'Section 4: Model Evaluation & Benchmark Comparison', 4);

  y = 36;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text('1. Independent Test-Set Classification Metrics', margin, y);

  y += 6;
  const lrM = trainingContext.logisticRegression.metrics;
  const rfM = trainingContext.randomForest.metrics;

  // Table header
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setFillColor(241, 245, 249);
  doc.rect(margin, y, contentWidth, 6, 'F');
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text('Model Architecture', margin + 4, y + 4.2);
  doc.text('Accuracy', margin + 54, y + 4.2);
  doc.text('Precision', margin + 80, y + 4.2);
  doc.text('Recall', margin + 106, y + 4.2);
  doc.text('F1 Score', margin + 130, y + 4.2);
  doc.text('ROC-AUC', margin + 155, y + 4.2);

  y += 6;
  const rows = [
    { name: 'Logistic Regression', m: lrM },
    { name: 'Random Forest (Ensemble)', m: rfM },
  ];

  rows.forEach((r) => {
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.text(r.name, margin + 4, y + 4.2);
    doc.text(`${(r.m.accuracy * 100).toFixed(1)}%`, margin + 54, y + 4.2);
    doc.text(`${(r.m.precision * 100).toFixed(1)}%`, margin + 80, y + 4.2);
    doc.text(`${(r.m.recall * 100).toFixed(1)}%`, margin + 106, y + 4.2);
    doc.text(`${(r.m.f1 * 100).toFixed(1)}%`, margin + 130, y + 4.2);
    doc.text(r.m.rocAuc.toFixed(3), margin + 155, y + 4.2);
    y += 6;
  });

  y += 8;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text(`2. Binary Confusion Matrix (${trainingContext.bestModelName})`, margin, y);

  y += 6;
  const bestCM = (trainingContext.bestModelName === 'Random Forest' ? rfM : lrM).confusionMatrix;
  const cmW = 40;
  const cmH = 14;

  // TN
  doc.setFillColor(241, 245, 249);
  doc.rect(margin + 30, y, cmW, cmH, 'F');
  doc.setDrawColor(203, 213, 225);
  doc.rect(margin + 30, y, cmW, cmH, 'S');
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(mutedColor[0], mutedColor[1], mutedColor[2]);
  doc.text('True Negatives (TN)', margin + 33, y + 5);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text(bestCM.tn.toString(), margin + 33, y + 11);

  // FP
  doc.setFillColor(254, 242, 242);
  doc.rect(margin + 75, y, cmW, cmH, 'F');
  doc.rect(margin + 75, y, cmW, cmH, 'S');
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(mutedColor[0], mutedColor[1], mutedColor[2]);
  doc.text('False Positives (FP)', margin + 78, y + 5);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text(bestCM.fp.toString(), margin + 78, y + 11);

  y += cmH + 3;

  // FN
  doc.setFillColor(254, 242, 242);
  doc.rect(margin + 30, y, cmW, cmH, 'F');
  doc.rect(margin + 30, y, cmW, cmH, 'S');
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(mutedColor[0], mutedColor[1], mutedColor[2]);
  doc.text('False Negatives (FN)', margin + 33, y + 5);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text(bestCM.fn.toString(), margin + 33, y + 11);

  // TP
  doc.setFillColor(240, 253, 244);
  doc.rect(margin + 75, y, cmW, cmH, 'F');
  doc.rect(margin + 75, y, cmW, cmH, 'S');
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(mutedColor[0], mutedColor[1], mutedColor[2]);
  doc.text('True Positives (TP)', margin + 78, y + 5);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text(bestCM.tp.toString(), margin + 78, y + 11);

  y += cmH + 10;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text('3. Feature Importance (Random Forest Gini Gain)', margin, y);

  y += 6;
  const topImp = trainingContext.randomForest.featureImportance.slice(0, 7);
  topImp.forEach((item) => {
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.text(item.feature, margin + 4, y + 3.5);

    // Bar visualization
    const barMax = 70;
    const barW = Math.max(2, item.importance * barMax);
    doc.setFillColor(14, 116, 144);
    doc.rect(margin + 65, y, barW, 4, 'F');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(mutedColor[0], mutedColor[1], mutedColor[2]);
    doc.text(`${(item.importance * 100).toFixed(1)}%`, margin + 68 + barW, y + 3.5);
    y += 5.5;
  });

  drawFooter();

  // ==========================================
  // PAGE 5: INSIGHTS & DISCLAIMER
  // ==========================================
  doc.addPage();
  drawHeader('Insurance Claim Analytics Report', 'Section 5: Dynamic Insights & Governance Notice', 5);

  y = 36;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text('1. Dynamically Derived Analytical Insights', margin, y);

  y += 6;
  insights.forEach((ins, idx) => {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8.5);
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.text(`${idx + 1}. ${ins.title} [${ins.highlight}]`, margin + 4, y);

    y += 4.5;
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(mutedColor[0], mutedColor[1], mutedColor[2]);
    const splitDesc = doc.splitTextToSize(ins.description, contentWidth - 8);
    doc.text(splitDesc, margin + 4, y);
    y += splitDesc.length * 4 + 3;
  });

  y += 6;
  // Governance & Disclaimer Box
  doc.setFillColor(254, 243, 199); // amber-100
  doc.roundedRect(margin, y, contentWidth, 36, 3, 3, 'F');
  doc.setDrawColor(245, 158, 11);
  doc.roundedRect(margin, y, contentWidth, 36, 3, 3, 'S');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(146, 64, 14); // amber-800
  doc.text('Mandatory Regulatory & Operational Disclaimer', margin + 6, y + 8);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(120, 53, 15);
  const disclaimerLines = [
    'This report and application provide a statistical machine-learning prediction based exclusively on patterns observed',
    'in historical training data. This system is not an automated insurance underwriting decision, claim approval or denial',
    'mechanism, fraud detection platform, or binding actuarial commitment.',
    'Underwriting decisions must always incorporate full human judgment, licensed actuarial guidelines, individual verification,',
    'and compliance with applicable statutory insurance regulations.',
  ];
  let dy = y + 14;
  disclaimerLines.forEach((line) => {
    doc.text(line, margin + 6, dy);
    dy += 4;
  });

  drawFooter();

  // Save the generated document
  doc.save('insurance-claim-prediction-report.pdf');
}
