import { CleanedPolicyRecord, DatasetStats } from '../types';

export interface GroupAnalysisItem {
  name: string;
  total: number;
  claims: number;
  noClaims: number;
  claimRate: number;
  avgPremium: number;
  avgVehicleAge?: number;
}

export function computeDatasetStats(records: CleanedPolicyRecord[]): DatasetStats {
  if (records.length === 0) {
    return {
      totalPolicies: 0,
      totalClaims: 0,
      totalNoClaims: 0,
      claimRate: 0,
      noClaimRate: 0,
      avgPremium: 0,
      avgCoverage: 0,
      avgCustomerAge: 0,
      avgPolicyTenure: 0,
      avgDrivingExperience: 0,
      avgVehicleAge: 0,
    };
  }

  const total = records.length;
  const totalClaims = records.filter((r) => r.claim === 1).length;
  const totalNoClaims = total - totalClaims;
  const claimRate = Number(((totalClaims / total) * 100).toFixed(2));
  const noClaimRate = Number((100 - claimRate).toFixed(2));

  const sumPremium = records.reduce((s, r) => s + r.premium_amount, 0);
  const sumCoverage = records.reduce((s, r) => s + r.coverage_amount, 0);
  const sumAge = records.reduce((s, r) => s + r.customer_age, 0);
  const sumTenure = records.reduce((s, r) => s + r.policy_tenure, 0);
  const sumExp = records.reduce((s, r) => s + r.driving_experience, 0);
  const sumVehAge = records.reduce((s, r) => s + r.vehicle_age, 0);

  return {
    totalPolicies: total,
    totalClaims,
    totalNoClaims,
    claimRate,
    noClaimRate,
    avgPremium: Math.round(sumPremium / total),
    avgCoverage: Math.round(sumCoverage / total),
    avgCustomerAge: Number((sumAge / total).toFixed(1)),
    avgPolicyTenure: Number((sumTenure / total).toFixed(1)),
    avgDrivingExperience: Number((sumExp / total).toFixed(1)),
    avgVehicleAge: Number((sumVehAge / total).toFixed(1)),
  };
}

export function analyzeByGroup(
  records: CleanedPolicyRecord[],
  keyFn: (r: CleanedPolicyRecord) => string,
  sortOrder?: string[]
): GroupAnalysisItem[] {
  const groups: Record<string, { total: number; claims: number; sumPrem: number; sumVehAge: number }> = {};

  for (const r of records) {
    const key = keyFn(r);
    if (!groups[key]) {
      groups[key] = { total: 0, claims: 0, sumPrem: 0, sumVehAge: 0 };
    }
    groups[key].total++;
    if (r.claim === 1) groups[key].claims++;
    groups[key].sumPrem += r.premium_amount;
    groups[key].sumVehAge += r.vehicle_age;
  }

  const result: GroupAnalysisItem[] = Object.keys(groups).map((name) => {
    const g = groups[name];
    const noClaims = g.total - g.claims;
    const claimRate = Number(((g.claims / g.total) * 100).toFixed(1));
    const avgPremium = Math.round(g.sumPrem / g.total);
    const avgVehicleAge = Number((g.sumVehAge / g.total).toFixed(1));
    return {
      name,
      total: g.total,
      claims: g.claims,
      noClaims,
      claimRate,
      avgPremium,
      avgVehicleAge,
    };
  });

  if (sortOrder) {
    result.sort((a, b) => {
      const idxA = sortOrder.indexOf(a.name);
      const idxB = sortOrder.indexOf(b.name);
      if (idxA !== -1 && idxB !== -1) return idxA - idxB;
      if (idxA !== -1) return -1;
      if (idxB !== -1) return 1;
      return a.name.localeCompare(b.name);
    });
  }

  return result;
}

export function analyzeByPolicyType(records: CleanedPolicyRecord[]): GroupAnalysisItem[] {
  return analyzeByGroup(records, (r) => r.policy_type);
}

export function analyzeByVehicleType(records: CleanedPolicyRecord[]): GroupAnalysisItem[] {
  return analyzeByGroup(records, (r) => r.vehicle_type);
}

export function analyzeByAgeGroup(records: CleanedPolicyRecord[]): GroupAnalysisItem[] {
  const order = ['Young Adult (<25)', 'Adult (25-39)', 'Middle Age (40-54)', 'Senior (55+)'];
  return analyzeByGroup(records, (r) => r.age_group, order);
}

export function analyzeByPremiumRange(records: CleanedPolicyRecord[]): GroupAnalysisItem[] {
  const order = ['<$1,000', '$1,000–$1,500', '$1,501–$2,000', '$2,001–$2,500', '>$2,500'];
  return analyzeByGroup(
    records,
    (r) => {
      const p = r.premium_amount;
      if (p < 1000) return '<$1,000';
      if (p <= 1500) return '$1,000–$1,500';
      if (p <= 2000) return '$1,501–$2,000';
      if (p <= 2500) return '$2,001–$2,500';
      return '>$2,500';
    },
    order
  );
}

export function analyzeByPreviousClaims(records: CleanedPolicyRecord[]): GroupAnalysisItem[] {
  const order = ['0 claims', '1 claim', '2 claims', '3 claims', '4+ claims'];
  return analyzeByGroup(
    records,
    (r) => {
      const c = r.previous_claims;
      if (c === 0) return '0 claims';
      if (c === 1) return '1 claim';
      if (c === 2) return '2 claims';
      if (c === 3) return '3 claims';
      return '4+ claims';
    },
    order
  );
}

export function analyzeByAccidentHistory(records: CleanedPolicyRecord[]): GroupAnalysisItem[] {
  return analyzeByGroup(records, (r) => (r.accident_history === 'Yes' ? 'Has Accident History' : 'No Accident History'));
}

export function analyzeByVehicleAge(records: CleanedPolicyRecord[]): GroupAnalysisItem[] {
  const order = ['New (0-2 yrs)', 'Moderately Used (3-7 yrs)', 'Older (8+ yrs)'];
  return analyzeByGroup(records, (r) => r.vehicle_age_group, order);
}

export function analyzeByPolicyTenure(records: CleanedPolicyRecord[]): GroupAnalysisItem[] {
  const order = ['<2 Years', '2-4 Years', '5-7 Years', '8+ Years'];
  return analyzeByGroup(
    records,
    (r) => {
      const t = r.policy_tenure;
      if (t < 2) return '<2 Years';
      if (t <= 4) return '2-4 Years';
      if (t <= 7) return '5-7 Years';
      return '8+ Years';
    },
    order
  );
}

export function analyzePremiumDistribution(records: CleanedPolicyRecord[]) {
  const claimPremiums = records.filter((r) => r.claim === 1).map((r) => r.premium_amount);
  const noClaimPremiums = records.filter((r) => r.claim === 0).map((r) => r.premium_amount);

  const avgClaimPremium = claimPremiums.length
    ? Math.round(claimPremiums.reduce((s, p) => s + p, 0) / claimPremiums.length)
    : 0;

  const avgNoClaimPremium = noClaimPremiums.length
    ? Math.round(noClaimPremiums.reduce((s, p) => s + p, 0) / noClaimPremiums.length)
    : 0;

  return {
    avgClaimPremium,
    avgNoClaimPremium,
    difference: avgClaimPremium - avgNoClaimPremium,
  };
}
