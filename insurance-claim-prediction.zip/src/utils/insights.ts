import { DatasetStats } from '../types';
import { TrainingContext } from '../ml/modelTraining';
import {
  analyzeByAgeGroup,
  analyzeByPolicyType,
  analyzeByPreviousClaims,
  analyzeByAccidentHistory,
  analyzePremiumDistribution,
} from './insuranceAnalysis';

export interface DynamicInsight {
  title: string;
  description: string;
  category: 'claim_pattern' | 'financial' | 'model' | 'risk_factor';
  highlight: string;
}

export function generateDynamicInsights(
  stats: DatasetStats,
  trainingContext: TrainingContext
): DynamicInsight[] {
  const records = [...trainingContext.trainRecords, ...trainingContext.testRecords];
  const insights: DynamicInsight[] = [];

  // 1. Overall claim rate insight
  insights.push({
    title: 'Overall Claim Rate',
    description: `Across ${stats.totalPolicies.toLocaleString()} examined policies, ${stats.totalClaims} filed a claim, representing a baseline portfolio claim frequency of ${stats.claimRate}%.`,
    category: 'claim_pattern',
    highlight: `${stats.claimRate}% Claim Rate`,
  });

  // 2. Policy Type with highest claim rate
  const policyTypes = analyzeByPolicyType(records);
  if (policyTypes.length > 0) {
    const sorted = [...policyTypes].sort((a, b) => b.claimRate - a.claimRate);
    const highest = sorted[0];
    const lowest = sorted[sorted.length - 1];
    insights.push({
      title: 'Policy Segment Variance',
      description: `${highest.name} policies exhibit the highest observed claim rate at ${highest.claimRate}% (avg premium $${highest.avgPremium.toLocaleString()}), whereas ${lowest.name} recorded the lowest at ${lowest.claimRate}%.`,
      category: 'claim_pattern',
      highlight: `${highest.name} (${highest.claimRate}%)`,
    });
  }

  // 3. Previous claims correlation
  const prevClaimsAnalysis = analyzeByPreviousClaims(records);
  const zeroClaims = prevClaimsAnalysis.find((g) => g.name === '0 claims');
  const multiClaims = prevClaimsAnalysis.find((g) => g.name === '2 claims' || g.name === '3 claims');
  if (zeroClaims && multiClaims) {
    insights.push({
      title: 'Impact of Previous Claim History',
      description: `Policyholders with 0 prior claims had an observed claim rate of ${zeroClaims.claimRate}%, compared to ${multiClaims.claimRate}% for those with historical claims.`,
      category: 'risk_factor',
      highlight: `${zeroClaims.claimRate}% vs ${multiClaims.claimRate}%`,
    });
  }

  // 4. Accident History Impact
  const accidentAnalysis = analyzeByAccidentHistory(records);
  const withAccident = accidentAnalysis.find((a) => a.name.includes('Has Accident'));
  const noAccident = accidentAnalysis.find((a) => a.name.includes('No Accident'));
  if (withAccident && noAccident) {
    insights.push({
      title: 'Prior Accident Risk Association',
      description: `Drivers with an existing accident record had a ${withAccident.claimRate}% claim incidence, compared to ${noAccident.claimRate}% for drivers with clear records.`,
      category: 'risk_factor',
      highlight: `+${(withAccident.claimRate - noAccident.claimRate).toFixed(1)}% Elevation`,
    });
  }

  // 5. Premium difference
  const premDist = analyzePremiumDistribution(records);
  insights.push({
    title: 'Claimant Premium Exposure',
    description: `Average premium for policies that resulted in a claim was $${premDist.avgClaimPremium.toLocaleString()} vs $${premDist.avgNoClaimPremium.toLocaleString()} for no-claim policies ($${Math.abs(premDist.difference).toLocaleString()} difference).`,
    category: 'financial',
    highlight: `$${premDist.avgClaimPremium.toLocaleString()} Avg Claim Premium`,
  });

  // 6. Best Performing Model
  const bestModel = trainingContext.bestModelName === 'Random Forest' ? trainingContext.randomForest : trainingContext.logisticRegression;
  const bestMetric = bestModel.metrics;
  insights.push({
    title: 'Champion Predictive Model',
    description: `${trainingContext.bestModelName} achieved the top balanced performance with an F1 score of ${(bestMetric.f1 * 100).toFixed(1)}%, ROC-AUC of ${bestMetric.rocAuc.toFixed(3)}, and overall test accuracy of ${(bestMetric.accuracy * 100).toFixed(1)}%.`,
    category: 'model',
    highlight: `${trainingContext.bestModelName} (F1: ${(bestMetric.f1 * 100).toFixed(1)}%)`,
  });

  // 7. Top Feature Importance
  const rfImportance = trainingContext.randomForest.featureImportance;
  if (rfImportance && rfImportance.length > 0) {
    const topFeature = rfImportance[0];
    const secondFeature = rfImportance[1];
    insights.push({
      title: 'Dominant Predictive Features',
      description: `The Random Forest model identified "${topFeature.feature}" as the primary driver of tree splits, closely followed by "${secondFeature?.feature || ''}".`,
      category: 'model',
      highlight: topFeature.feature,
    });
  }

  return insights;
}
