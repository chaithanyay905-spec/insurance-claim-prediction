import { CleanedPolicyRecord, ModelTrainingResult, PredictionInput, PredictionResult } from '../types';
import { fitFeatureEncoder, encodeRecord, encodePredictionInput, FittedFeatureEncoder } from './encoding';
import { evaluatePredictions } from './metrics';
import { LogisticRegressionModel } from './logisticRegression';
import { RandomForestClassifierModel } from './randomForest';

export interface TrainingContext {
  trainRecords: CleanedPolicyRecord[];
  testRecords: CleanedPolicyRecord[];
  trainSize: number;
  testSize: number;
  numFeatures: number;
  encoder: FittedFeatureEncoder;
  logisticRegression: ModelTrainingResult;
  randomForest: ModelTrainingResult;
  bestModelName: 'Logistic Regression' | 'Random Forest';
  trainedAt: string;
}

export function stratifiedSplit(
  records: CleanedPolicyRecord[],
  trainRatio = 0.8
): { train: CleanedPolicyRecord[]; test: CleanedPolicyRecord[] } {
  const class0 = records.filter((r) => r.claim === 0);
  const class1 = records.filter((r) => r.claim === 1);

  // Shuffle both classes deterministically or with pseudo-random seed
  const shuffle = (arr: CleanedPolicyRecord[]) => {
    const copy = [...arr];
    for (let i = copy.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [copy[i], copy[j]] = [copy[j], copy[i]];
    }
    return copy;
  };

  const shuffled0 = shuffle(class0);
  const shuffled1 = shuffle(class1);

  const trainCount0 = Math.floor(shuffled0.length * trainRatio);
  const trainCount1 = Math.floor(shuffled1.length * trainRatio);

  const train = [...shuffled0.slice(0, trainCount0), ...shuffled1.slice(0, trainCount1)];
  const test = [...shuffled0.slice(trainCount0), ...shuffled1.slice(trainCount1)];

  return { train: shuffle(train), test: shuffle(test) };
}

export function trainModels(
  records: CleanedPolicyRecord[],
  uniquePolicyTypes: string[],
  uniqueVehicleTypes: string[],
  uniqueGenders: string[],
  uniqueVehicleUsages: string[]
): TrainingContext {
  const { train, test } = stratifiedSplit(records, 0.8);

  const encoder = fitFeatureEncoder(
    train,
    uniquePolicyTypes,
    uniqueVehicleTypes,
    uniqueGenders,
    uniqueVehicleUsages
  );

  const X_train = train.map((r) => encodeRecord(r, encoder, true));
  const y_train = train.map((r) => r.claim);

  const X_test = test.map((r) => encodeRecord(r, encoder, true));
  const y_test = test.map((r) => r.claim);

  // 1. Train Logistic Regression
  const lrStart = performance.now();
  const lr = new LogisticRegressionModel(encoder.featureNames);
  lr.train(X_train, y_train, 250, 0.08, 0.001);
  const lrTime = performance.now() - lrStart;

  const lrProbs = X_test.map((x) => lr.predictProbability(x));
  const lrPreds = lrProbs.map((p) => (p >= 0.5 ? 1 : 0));
  const lrMetrics = evaluatePredictions(y_test, lrProbs, 0.5);
  const lrImportance = lr.getFeatureImportance();

  const lrResult: ModelTrainingResult = {
    name: 'Logistic Regression',
    metrics: lrMetrics,
    testProbabilities: lrProbs,
    testPredictions: lrPreds,
    testActuals: y_test,
    featureImportance: lrImportance,
    trainTimeMs: Math.round(lrTime),
    predict: (features: number[]) => {
      const prob = lr.predictProbability(features);
      return { probability: prob, prediction: prob >= 0.5 ? 1 : 0 };
    },
  };

  // 2. Train Random Forest
  const rfStart = performance.now();
  const rf = new RandomForestClassifierModel(encoder.featureNames, 22, 6);
  rf.train(X_train, y_train);
  const rfTime = performance.now() - rfStart;

  const rfProbs = X_test.map((x) => rf.predictProbability(x));
  const rfPreds = rfProbs.map((p) => (p >= 0.5 ? 1 : 0));
  const rfMetrics = evaluatePredictions(y_test, rfProbs, 0.5);
  const rfImportance = rf.getFeatureImportance();

  const rfResult: ModelTrainingResult = {
    name: 'Random Forest',
    metrics: rfMetrics,
    testProbabilities: rfProbs,
    testPredictions: rfPreds,
    testActuals: y_test,
    featureImportance: rfImportance,
    trainTimeMs: Math.round(rfTime),
    predict: (features: number[]) => {
      const prob = rf.predictProbability(features);
      return { probability: prob, prediction: prob >= 0.5 ? 1 : 0 };
    },
  };

  // Determine best model based on F1 score and ROC-AUC
  const lrScore = lrMetrics.f1 * 0.6 + lrMetrics.rocAuc * 0.4;
  const rfScore = rfMetrics.f1 * 0.6 + rfMetrics.rocAuc * 0.4;
  const bestModelName: 'Logistic Regression' | 'Random Forest' = rfScore >= lrScore ? 'Random Forest' : 'Logistic Regression';

  return {
    trainRecords: train,
    testRecords: test,
    trainSize: train.length,
    testSize: test.length,
    numFeatures: encoder.featureNames.length,
    encoder,
    logisticRegression: lrResult,
    randomForest: rfResult,
    bestModelName,
    trainedAt: new Date().toISOString(),
  };
}

export function predictSingle(
  input: PredictionInput,
  context: TrainingContext,
  selectedModel: 'Logistic Regression' | 'Random Forest' = 'Random Forest',
  threshold = 0.5
): PredictionResult {
  const featureVector = encodePredictionInput(input, context.encoder, true);
  const model = selectedModel === 'Random Forest' ? context.randomForest : context.logisticRegression;

  const { probability } = model.predict(featureVector);
  const predictedClass = probability >= threshold ? 1 : 0;
  const confidence = Number((predictedClass === 1 ? probability : 1 - probability).toFixed(4));

  // Determine key factors for this individual
  const topFactors: { factor: string; impact: 'increases risk' | 'decreases risk' | 'neutral'; description: string }[] = [];

  if (input.previous_claims > 0) {
    topFactors.push({
      factor: 'Previous Claims',
      impact: 'increases risk',
      description: `${input.previous_claims} previous claim(s) recorded in history.`,
    });
  }
  if (input.accident_history.toLowerCase() === 'yes') {
    topFactors.push({
      factor: 'Accident History',
      impact: 'increases risk',
      description: 'Customer has an existing prior accident record on file.',
    });
  }
  if (input.driving_experience < 3) {
    topFactors.push({
      factor: 'Driving Experience',
      impact: 'increases risk',
      description: `Novice driver with only ${input.driving_experience} year(s) on the road.`,
    });
  } else if (input.driving_experience >= 10) {
    topFactors.push({
      factor: 'Driving Experience',
      impact: 'decreases risk',
      description: `Experienced driver with ${input.driving_experience} years of experience.`,
    });
  }
  if (input.vehicle_usage === 'Commercial') {
    topFactors.push({
      factor: 'Vehicle Usage',
      impact: 'increases risk',
      description: 'Commercial usage vehicle with higher road exposure and duty cycle.',
    });
  }
  if (input.policy_tenure >= 5) {
    topFactors.push({
      factor: 'Policy Tenure',
      impact: 'decreases risk',
      description: `Established customer relationship of ${input.policy_tenure} years.`,
    });
  }
  if (input.vehicle_age >= 9) {
    topFactors.push({
      factor: 'Vehicle Age',
      impact: 'increases risk',
      description: `Older vehicle (${input.vehicle_age} yrs) with higher mechanical failure exposure.`,
    });
  }

  return {
    predictedClass,
    claimProbability: probability,
    noClaimProbability: Number((1 - probability).toFixed(4)),
    confidence,
    threshold,
    modelUsed: selectedModel,
    input,
    timestamp: new Date().toLocaleTimeString(),
    topFactors,
  };
}
