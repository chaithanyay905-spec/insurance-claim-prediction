import { FeatureImportanceItem } from '../types';

interface TreeNode {
  isLeaf: boolean;
  featureIndex?: number;
  threshold?: number;
  left?: TreeNode;
  right?: TreeNode;
  value?: number; // 0 or 1
  probability: number; // Proportion of class 1 in this leaf
}

class DecisionTree {
  public root: TreeNode | null = null;
  public maxDepth: number;
  public minSamplesSplit: number;
  public featureImportances: number[] = [];

  constructor(maxDepth = 6, minSamplesSplit = 4) {
    this.maxDepth = maxDepth;
    this.minSamplesSplit = minSamplesSplit;
  }

  private calculateGini(labels: number[]): number {
    if (labels.length === 0) return 0;
    let count1 = 0;
    for (const l of labels) {
      if (l === 1) count1++;
    }
    const p1 = count1 / labels.length;
    const p0 = 1 - p1;
    return 1 - (p0 * p0 + p1 * p1);
  }

  public train(X: number[][], y: number[], numFeaturesPerSplit: number): void {
    const numFeatures = X[0].length;
    this.featureImportances = new Array(numFeatures).fill(0);
    this.root = this.buildTree(X, y, 0, numFeaturesPerSplit);
  }

  private buildTree(
    X: number[][],
    y: number[],
    depth: number,
    numFeaturesPerSplit: number
  ): TreeNode {
    const numSamples = X.length;
    const num1 = y.filter((l) => l === 1).length;
    const prob1 = numSamples > 0 ? num1 / numSamples : 0;
    const majorityClass = prob1 >= 0.5 ? 1 : 0;

    // Stopping criteria: pure node, max depth reached, or too few samples
    if (
      depth >= this.maxDepth ||
      numSamples < this.minSamplesSplit ||
      num1 === 0 ||
      num1 === numSamples
    ) {
      return {
        isLeaf: true,
        value: majorityClass,
        probability: prob1,
      };
    }

    const parentGini = this.calculateGini(y);
    const numFeatures = X[0].length;

    // Random feature subset selection (Random Forest subspace sampling)
    const allFeatureIndices = Array.from({ length: numFeatures }, (_, i) => i);
    for (let i = allFeatureIndices.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [allFeatureIndices[i], allFeatureIndices[j]] = [allFeatureIndices[j], allFeatureIndices[i]];
    }
    const selectedFeatureIndices = allFeatureIndices.slice(0, numFeaturesPerSplit);

    let bestGiniGain = -1;
    let bestFeature = -1;
    let bestThreshold = 0;
    let bestLeftIndices: number[] = [];
    let bestRightIndices: number[] = [];

    for (const fIdx of selectedFeatureIndices) {
      // Find candidate thresholds (unique values or percentiles)
      const values = X.map((row) => row[fIdx]);
      const uniqueVals = Array.from(new Set(values)).sort((a, b) => a - b);

      // Test midpoint splits
      const numTests = Math.min(uniqueVals.length - 1, 10);
      const step = Math.max(1, Math.floor((uniqueVals.length - 1) / numTests));

      for (let k = 0; k < uniqueVals.length - 1; k += step) {
        const threshold = (uniqueVals[k] + uniqueVals[k + 1]) / 2;

        const leftIndices: number[] = [];
        const rightIndices: number[] = [];

        for (let i = 0; i < numSamples; i++) {
          if (X[i][fIdx] <= threshold) {
            leftIndices.push(i);
          } else {
            rightIndices.push(i);
          }
        }

        if (leftIndices.length === 0 || rightIndices.length === 0) continue;

        const leftLabels = leftIndices.map((idx) => y[idx]);
        const rightLabels = rightIndices.map((idx) => y[idx]);

        const leftGini = this.calculateGini(leftLabels);
        const rightGini = this.calculateGini(rightLabels);

        const weightedGini =
          (leftIndices.length / numSamples) * leftGini +
          (rightIndices.length / numSamples) * rightGini;

        const giniGain = parentGini - weightedGini;

        if (giniGain > bestGiniGain) {
          bestGiniGain = giniGain;
          bestFeature = fIdx;
          bestThreshold = threshold;
          bestLeftIndices = leftIndices;
          bestRightIndices = rightIndices;
        }
      }
    }

    if (bestGiniGain <= 0.0001 || bestFeature === -1) {
      return {
        isLeaf: true,
        value: majorityClass,
        probability: prob1,
      };
    }

    // Accumulate weighted Gini importance
    this.featureImportances[bestFeature] += bestGiniGain * numSamples;

    const leftX = bestLeftIndices.map((idx) => X[idx]);
    const leftY = bestLeftIndices.map((idx) => y[idx]);
    const rightX = bestRightIndices.map((idx) => X[idx]);
    const rightY = bestRightIndices.map((idx) => y[idx]);

    const leftChild = this.buildTree(leftX, leftY, depth + 1, numFeaturesPerSplit);
    const rightChild = this.buildTree(rightX, rightY, depth + 1, numFeaturesPerSplit);

    return {
      isLeaf: false,
      featureIndex: bestFeature,
      threshold: bestThreshold,
      left: leftChild,
      right: rightChild,
      probability: prob1,
    };
  }

  public predictProbability(x: number[]): number {
    let node = this.root;
    while (node && !node.isLeaf) {
      if (node.featureIndex !== undefined && node.threshold !== undefined) {
        if (x[node.featureIndex] <= node.threshold) {
          node = node.left || null;
        } else {
          node = node.right || null;
        }
      } else {
        break;
      }
    }
    return node ? node.probability : 0.5;
  }
}

export class RandomForestClassifierModel {
  public trees: DecisionTree[] = [];
  public numTrees: number;
  public maxDepth: number;
  public featureNames: string[];
  public globalFeatureImportances: number[] = [];

  constructor(featureNames: string[] = [], numTrees = 20, maxDepth = 6) {
    this.featureNames = featureNames;
    this.numTrees = numTrees;
    this.maxDepth = maxDepth;
  }

  public train(X: number[][], y: number[]): void {
    const numSamples = X.length;
    const numFeatures = X[0].length;
    const numFeaturesPerSplit = Math.max(1, Math.floor(Math.sqrt(numFeatures)));

    this.trees = [];
    this.globalFeatureImportances = new Array(numFeatures).fill(0);

    for (let t = 0; t < this.numTrees; t++) {
      // Bootstrap sampling (sample with replacement)
      const bootX: number[][] = [];
      const bootY: number[] = [];
      for (let i = 0; i < numSamples; i++) {
        const randIdx = Math.floor(Math.random() * numSamples);
        bootX.push(X[randIdx]);
        bootY.push(y[randIdx]);
      }

      const tree = new DecisionTree(this.maxDepth, 4);
      tree.train(bootX, bootY, numFeaturesPerSplit);
      this.trees.push(tree);

      for (let j = 0; j < numFeatures; j++) {
        this.globalFeatureImportances[j] += tree.featureImportances[j] || 0;
      }
    }
  }

  public predictProbability(x: number[]): number {
    if (this.trees.length === 0) return 0.5;
    let sumProb = 0;
    for (const tree of this.trees) {
      sumProb += tree.predictProbability(x);
    }
    return Number((sumProb / this.trees.length).toFixed(4));
  }

  public predict(x: number[], threshold = 0.5): number {
    return this.predictProbability(x) >= threshold ? 1 : 0;
  }

  public getFeatureImportance(): FeatureImportanceItem[] {
    const maxVal = Math.max(...this.globalFeatureImportances, 0.0001);
    const items: FeatureImportanceItem[] = this.globalFeatureImportances.map((val, idx) => ({
      feature: this.featureNames[idx] || `feature_${idx}`,
      importance: Number((val / maxVal).toFixed(4)),
      description: 'Derived from aggregate Gini impurity reduction across decision trees',
    }));

    return items.sort((a, b) => b.importance - a.importance);
  }
}
