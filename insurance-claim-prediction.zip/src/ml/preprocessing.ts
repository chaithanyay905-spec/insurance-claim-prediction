import Papa from 'papaparse';
import { RawPolicyRecord, CleanedPolicyRecord } from '../types';
import { engineerFeatures } from './featureEngineering';

export interface PreprocessingResult {
  records: CleanedPolicyRecord[];
  totalParsed: number;
  validRecordsCount: number;
  removedRecordsCount: number;
  duplicatesRemovedCount: number;
  uniquePolicyTypes: string[];
  uniqueVehicleTypes: string[];
  uniqueGenders: string[];
  uniqueVehicleUsages: string[];
}

function calculateMedian(values: number[]): number {
  if (values.length === 0) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 !== 0 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
}

function calculateMode(values: string[]): string {
  if (values.length === 0) return 'Unknown';
  const counts: Record<string, number> = {};
  let maxCount = 0;
  let mode = values[0];
  for (const v of values) {
    if (!v) continue;
    counts[v] = (counts[v] || 0) + 1;
    if (counts[v] > maxCount) {
      maxCount = counts[v];
      mode = v;
    }
  }
  return mode;
}

export function normalizeTargetClaim(val: any): 0 | 1 | null {
  if (val === null || val === undefined) return null;
  const str = String(val).trim().toLowerCase();
  if (str === '1' || str === 'yes' || str === 'claim' || str === 'true' || str === 'positive') {
    return 1;
  }
  if (str === '0' || str === 'no' || str === 'no claim' || str === 'false' || str === 'negative') {
    return 0;
  }
  return null;
}

export function normalizeGender(val: string): 'Male' | 'Female' | 'Other' {
  if (!val) return 'Male';
  const v = val.trim().toLowerCase();
  if (v === 'male' || v === 'm') return 'Male';
  if (v === 'female' || v === 'f') return 'Female';
  return 'Other';
}

export function normalizeVehicleUsage(val: string): 'Personal' | 'Commercial' | 'Mixed' {
  if (!val) return 'Personal';
  const v = val.trim().toLowerCase();
  if (v.includes('commercial')) return 'Commercial';
  if (v.includes('mixed')) return 'Mixed';
  return 'Personal';
}

export function normalizeYesNo(val: string): 'Yes' | 'No' {
  if (!val) return 'No';
  const v = val.trim().toLowerCase();
  return v === 'yes' || v === '1' || v === 'true' ? 'Yes' : 'No';
}

export async function loadAndPreprocessInsuranceData(csvUrl = '/data/insurance_claims.csv'): Promise<PreprocessingResult> {
  const response = await fetch(csvUrl);
  if (!response.ok) {
    throw new Error(`Failed to load dataset: ${response.status} ${response.statusText}`);
  }

  const csvText = await response.text();

  return new Promise((resolve, reject) => {
    Papa.parse<RawPolicyRecord>(csvText, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        try {
          const rawRows = results.data;
          const totalParsed = rawRows.length;
          let removedCount = 0;

          // 1. Filter records with missing target or completely empty records
          const filteredRows: RawPolicyRecord[] = [];
          const seenIds = new Set<string>();
          let duplicatesRemoved = 0;

          for (const row of rawRows) {
            if (!row.policy_id) {
              removedCount++;
              continue;
            }

            const cleanId = String(row.policy_id).trim();
            if (seenIds.has(cleanId)) {
              duplicatesRemoved++;
              continue;
            }
            seenIds.add(cleanId);

            const target = normalizeTargetClaim(row.claim);
            if (target === null) {
              removedCount++;
              continue;
            }

            filteredRows.push(row);
          }

          // 2. Gather values for imputation
          const ages: number[] = [];
          const vehicleAges: number[] = [];
          const incomes: number[] = [];
          const tenures: number[] = [];
          const premiums: number[] = [];
          const coverages: number[] = [];
          const prevClaims: number[] = [];
          const experiences: number[] = [];

          const policyTypesList: string[] = [];
          const vehicleTypesList: string[] = [];
          const gendersList: string[] = [];
          const vehicleUsagesList: string[] = [];

          for (const r of filteredRows) {
            const age = Number(r.customer_age);
            if (!isNaN(age) && age > 0) ages.push(age);

            const va = Number(r.vehicle_age);
            if (!isNaN(va) && va >= 0) vehicleAges.push(va);

            const inc = Number(r.annual_income);
            if (!isNaN(inc) && inc > 0) incomes.push(inc);

            const ten = Number(r.policy_tenure);
            if (!isNaN(ten) && ten >= 0) tenures.push(ten);

            const prem = Number(r.premium_amount);
            if (!isNaN(prem) && prem > 0) premiums.push(prem);

            const cov = Number(r.coverage_amount);
            if (!isNaN(cov) && cov > 0) coverages.push(cov);

            const pc = Number(r.previous_claims);
            if (!isNaN(pc) && pc >= 0) prevClaims.push(pc);

            const exp = Number(r.driving_experience);
            if (!isNaN(exp) && exp >= 0) experiences.push(exp);

            if (r.policy_type) policyTypesList.push(r.policy_type.trim());
            if (r.vehicle_type) vehicleTypesList.push(r.vehicle_type.trim());
            if (r.gender) gendersList.push(normalizeGender(r.gender));
            if (r.vehicle_usage) vehicleUsagesList.push(normalizeVehicleUsage(r.vehicle_usage));
          }

          const medianAge = Math.round(calculateMedian(ages)) || 42;
          const medianVehicleAge = Math.round(calculateMedian(vehicleAges)) || 5;
          const medianIncome = Math.round(calculateMedian(incomes)) || 65000;
          const medianTenure = Math.round(calculateMedian(tenures)) || 4;
          const medianPremium = Math.round(calculateMedian(premiums)) || 1400;
          const medianCoverage = Math.round(calculateMedian(coverages)) || 45000;
          const medianPrevClaims = Math.round(calculateMedian(prevClaims)) || 0;
          const medianExperience = Math.round(calculateMedian(experiences)) || 10;

          const modePolicyType = calculateMode(policyTypesList) || 'Comprehensive';
          const modeVehicleType = calculateMode(vehicleTypesList) || 'Sedan';

          // 3. Clean and normalize each record
          const cleanedRecords: CleanedPolicyRecord[] = [];

          for (const r of filteredRows) {
            const age = isNaN(Number(r.customer_age)) ? medianAge : Number(r.customer_age);
            const vehicle_age = isNaN(Number(r.vehicle_age)) ? medianVehicleAge : Number(r.vehicle_age);
            const annual_income = isNaN(Number(r.annual_income)) ? medianIncome : Number(r.annual_income);
            const policy_tenure = isNaN(Number(r.policy_tenure)) ? medianTenure : Number(r.policy_tenure);
            const premium_amount = isNaN(Number(r.premium_amount)) ? medianPremium : Number(r.premium_amount);
            const coverage_amount = isNaN(Number(r.coverage_amount)) ? medianCoverage : Number(r.coverage_amount);
            const previous_claims = isNaN(Number(r.previous_claims)) ? medianPrevClaims : Number(r.previous_claims);
            const driving_experience = isNaN(Number(r.driving_experience)) ? medianExperience : Number(r.driving_experience);

            const gender = normalizeGender(r.gender);
            const policy_type = (r.policy_type && r.policy_type.trim()) ? r.policy_type.trim() : modePolicyType;
            const vehicle_type = (r.vehicle_type && r.vehicle_type.trim()) ? r.vehicle_type.trim() : modeVehicleType;
            const vehicle_usage = normalizeVehicleUsage(r.vehicle_usage);
            const accident_history = normalizeYesNo(r.accident_history);
            const claim_history = normalizeYesNo(r.claim_history);
            const claim = normalizeTargetClaim(r.claim) as (0 | 1);

            const record = engineerFeatures({
              policy_id: String(r.policy_id).trim(),
              customer_age: Math.max(18, Math.min(100, age)),
              gender,
              policy_type,
              vehicle_type,
              vehicle_age: Math.max(0, Math.min(30, vehicle_age)),
              annual_income: Math.max(5000, annual_income),
              policy_tenure: Math.max(0, Math.min(40, policy_tenure)),
              premium_amount: Math.max(50, premium_amount),
              coverage_amount: Math.max(1000, coverage_amount),
              previous_claims: Math.max(0, Math.min(15, previous_claims)),
              accident_history,
              driving_experience: Math.max(0, Math.min(60, driving_experience)),
              vehicle_usage,
              claim_history,
              claim,
            });

            cleanedRecords.push(record);
          }

          const uniquePolicyTypes = Array.from(new Set(cleanedRecords.map((r) => r.policy_type))).sort();
          const uniqueVehicleTypes = Array.from(new Set(cleanedRecords.map((r) => r.vehicle_type))).sort();
          const uniqueGenders = Array.from(new Set(cleanedRecords.map((r) => r.gender))).sort();
          const uniqueVehicleUsages = Array.from(new Set(cleanedRecords.map((r) => r.vehicle_usage))).sort();

          resolve({
            records: cleanedRecords,
            totalParsed,
            validRecordsCount: cleanedRecords.length,
            removedRecordsCount: removedCount,
            duplicatesRemovedCount: duplicatesRemoved,
            uniquePolicyTypes,
            uniqueVehicleTypes,
            uniqueGenders,
            uniqueVehicleUsages,
          });
        } catch (err) {
          reject(err);
        }
      },
      error: (err) => {
        reject(err);
      },
    });
  });
}
