import { CleanedPolicyRecord, PredictionInput } from '../types';

export function deriveAgeGroup(age: number): string {
  if (age < 25) return 'Young Adult (<25)';
  if (age < 40) return 'Adult (25-39)';
  if (age < 55) return 'Middle Age (40-54)';
  return 'Senior (55+)';
}

export function deriveVehicleAgeGroup(vehicleAge: number): string {
  if (vehicleAge <= 2) return 'New (0-2 yrs)';
  if (vehicleAge <= 7) return 'Moderately Used (3-7 yrs)';
  return 'Older (8+ yrs)';
}

export function deriveExperienceGroup(experience: number): string {
  if (experience < 3) return 'Novice (<3 yrs)';
  if (experience < 8) return 'Intermediate (3-7 yrs)';
  return 'Experienced (8+ yrs)';
}

export function calculatePremiumCoverageRatio(premium: number, coverage: number): number {
  if (!coverage || coverage <= 0) return 0;
  return Number((premium / coverage).toFixed(5));
}

export function engineerFeatures(
  base: Omit<CleanedPolicyRecord, 'age_group' | 'vehicle_age_group' | 'premium_to_coverage_ratio' | 'accident_indicator' | 'claim_history_indicator' | 'experience_group'>
): CleanedPolicyRecord {
  return {
    ...base,
    age_group: deriveAgeGroup(base.customer_age),
    vehicle_age_group: deriveVehicleAgeGroup(base.vehicle_age),
    experience_group: deriveExperienceGroup(base.driving_experience),
    premium_to_coverage_ratio: calculatePremiumCoverageRatio(base.premium_amount, base.coverage_amount),
    accident_indicator: base.accident_history.toLowerCase() === 'yes' ? 1 : 0,
    claim_history_indicator: base.claim_history.toLowerCase() === 'yes' ? 1 : 0,
  };
}

export function engineerFeaturesForInput(input: PredictionInput) {
  return {
    ...input,
    age_group: deriveAgeGroup(input.customer_age),
    vehicle_age_group: deriveVehicleAgeGroup(input.vehicle_age),
    experience_group: deriveExperienceGroup(input.driving_experience),
    premium_to_coverage_ratio: calculatePremiumCoverageRatio(input.premium_amount, input.coverage_amount),
    accident_indicator: input.accident_history.toLowerCase() === 'yes' ? 1 : 0,
    claim_history_indicator: input.claim_history.toLowerCase() === 'yes' ? 1 : 0,
  };
}
