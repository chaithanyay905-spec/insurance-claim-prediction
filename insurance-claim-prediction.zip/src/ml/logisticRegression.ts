import { FeatureImportanceItem } from '../types';

export class LogisticRegressionModel {
  public weights: number[] = [];
  public bias: number = 0;
  public featureNames: string[] = [];

  constructor(featureNames: string[] = []) {
    this.featureNames = featureNames;
  }

  private sigmoid(z: number): number {
    if (z > 25) return 1.0;
    if (z < -25) return 0.0;
    return 1.0 / (1.0 + Math.exp(-z));
  }

  public train(
    X: number[][],
    y: number[],
    epochs: number = 250,
    learningRate: number = 0.08,
    lambdaL2: number = 0.001
  ): void {
    const numSamples = X.length;
    const numFeatures = X[0].length;

    // Xavier/He-like small random initialization
    this.weights = new Array(numFeatures).fill(0).map(() => (Math.random() - 0.5) * 0.05);
    this.bias = 0;

    for (let epoch = 0; epoch < epochs; epoch++) {
      const lr = learningRate / (1 + 0.002 * epoch);

      const dW = new Array(numFeatures).fill(0);
      let dB = 0;

      for (let i = 0; i < numSamples; i++) {
        let z = this.bias;
        for (let j = 0; j < numFeatures; j++) {
          z += this.weights[j] * X[i][j];
        }

        const yHat = this.sigmoid(z);
        const error = yHat - y[i];

        for (let j = 0; j < numFeatures; j++) {
          dW[j] += error * X[i][j];
        }
        dB += error;
      }

      // Update weights with L2 regularization penalty
      for (let j = 0; j < numFeatures; j++) {
        this.weights[j] -= lr * (dW[j] / numSamples + lambdaL2 * this.weights[j]);
      }
      this.bias -= lr * (dB / numSamples);
    }
  }

  public predictProbability(x: number[]): number {
    let z = this.bias;
    for (let j = 0; j < this.weights.length; j++) {
      z += this.weights[j] * (x[j] || 0);
    }
    const prob = this.sigmoid(z);
    return Number(prob.toFixed(4));
  }

  public predict(x: number[], threshold = 0.5): number {
    return this.predictProbability(x) >= threshold ? 1 : 0;
  }

  public getFeatureImportance(): FeatureImportanceItem[] {
    const items: FeatureImportanceItem[] = this.weights.map((w, idx) => {
      const feature = this.featureNames[idx] || `feature_${idx}`;
      return {
        feature,
        importance: Math.abs(w),
        description: w > 0 ? 'Positive coefficient (Increases risk)' : 'Negative coefficient (Reduces risk)',
      };
    });

    const maxImp = Math.max(...items.map((i) => i.importance), 0.0001);
    const normalized = items.map((i) => ({
      feature: i.feature,
      importance: Number((i.importance / maxImp).toFixed(4)),
      description: i.description,
    }));

    return normalized.sort((a, b) => b.importance - a.importance);
  }
}
