import { CleanedPolicyRecord, PredictionInput } from '../types';
import { engineerFeaturesForInput } from './featureEngineering';
import { normalizeGender, normalizeVehicleUsage, normalizeYesNo } from './preprocessing';

export interface FeatureScaler {
  mean: number;
  std: number;
}

export interface FittedFeatureEncoder {
  featureNames: string[];
  numericColumns: string[];
  categoricalColumns: {
    column: string;
    values: string[];
  }[];
  scalers: Record<string, FeatureScaler>;
}

export function fitFeatureEncoder(
  records: CleanedPolicyRecord[],
  uniquePolicyTypes: string[],
  uniqueVehicleTypes: string[],
  uniqueGenders: string[],
  uniqueVehicleUsages: string[]
): FittedFeatureEncoder {
  const numericColumns = [
    'customer_age',
    'vehicle_age',
    'annual_income',
    'policy_tenure',
    'premium_amount',
    'coverage_amount',
    'previous_claims',
    'driving_experience',
    'premium_to_coverage_ratio',
    'accident_indicator',
    'claim_history_indicator',
  ];

  const categoricalColumns = [
    { column: 'gender', values: uniqueGenders },
    { column: 'policy_type', values: uniquePolicyTypes },
    { column: 'vehicle_type', values: uniqueVehicleTypes },
    { column: 'vehicle_usage', values: uniqueVehicleUsages },
  ];

  // Calculate mean & std for numerical columns
  const scalers: Record<string, FeatureScaler> = {};
  for (const col of numericColumns) {
    const vals = records.map((r) => Number((r as any)[col]) || 0);
    const mean = vals.reduce((sum, v) => sum + v, 0) / vals.length;
    const variance = vals.reduce((sum, v) => sum + Math.pow(v - mean, 2), 0) / (vals.length || 1);
    const std = Math.sqrt(variance) || 1;
    scalers[col] = { mean, std };
  }

  // Build full list of feature names
  const featureNames: string[] = [];
  for (const col of numericColumns) {
    featureNames.push(col);
  }
  for (const cat of categoricalColumns) {
    for (const val of cat.values) {
      featureNames.push(`${cat.column}_${val}`);
    }
  }

  return {
    featureNames,
    numericColumns,
    categoricalColumns,
    scalers,
  };
}

export function encodeRecord(
  record: CleanedPolicyRecord,
  encoder: FittedFeatureEncoder,
  standardizeNumerics: boolean = true
): number[] {
  const vector: number[] = [];

  // 1. Numeric features
  for (const col of encoder.numericColumns) {
    const rawVal = Number((record as any)[col]) || 0;
    if (standardizeNumerics && encoder.scalers[col]) {
      const { mean, std } = encoder.scalers[col];
      vector.push((rawVal - mean) / std);
    } else {
      vector.push(rawVal);
    }
  }

  // 2. One-hot categorical features
  for (const cat of encoder.categoricalColumns) {
    const currentVal = String((record as any)[cat.column] || '');
    for (const val of cat.values) {
      vector.push(currentVal.toLowerCase() === val.toLowerCase() ? 1 : 0);
    }
  }

  return vector;
}

export function encodePredictionInput(
  input: PredictionInput,
  encoder: FittedFeatureEncoder,
  standardizeNumerics: boolean = true
): number[] {
  const engineered = engineerFeaturesForInput({
    ...input,
    gender: normalizeGender(input.gender),
    vehicle_usage: normalizeVehicleUsage(input.vehicle_usage),
    accident_history: normalizeYesNo(input.accident_history),
    claim_history: normalizeYesNo(input.claim_history),
  });

  const vector: number[] = [];

  // 1. Numeric features
  for (const col of encoder.numericColumns) {
    const rawVal = Number((engineered as any)[col]) || 0;
    if (standardizeNumerics && encoder.scalers[col]) {
      const { mean, std } = encoder.scalers[col];
      vector.push((rawVal - mean) / std);
    } else {
      vector.push(rawVal);
    }
  }

  // 2. Categorical features
  for (const cat of encoder.categoricalColumns) {
    const currentVal = String((engineered as any)[cat.column] || '');
    for (const val of cat.values) {
      vector.push(currentVal.toLowerCase() === val.toLowerCase() ? 1 : 0);
    }
  }

  return vector;
}
