import { ClassificationMetrics, ConfusionMatrixData } from '../types';

export function calculateConfusionMatrix(
  actuals: number[],
  probabilities: number[],
  threshold = 0.5
): ConfusionMatrixData {
  let tn = 0;
  let fp = 0;
  let fn = 0;
  let tp = 0;

  for (let i = 0; i < actuals.length; i++) {
    const actual = actuals[i];
    const predicted = probabilities[i] >= threshold ? 1 : 0;

    if (actual === 0 && predicted === 0) tn++;
    else if (actual === 0 && predicted === 1) fp++;
    else if (actual === 1 && predicted === 0) fn++;
    else if (actual === 1 && predicted === 1) tp++;
  }

  return { tn, fp, fn, tp };
}

export function calculateRocAuc(actuals: number[], probabilities: number[]): number {
  if (actuals.length === 0) return 0.5;

  // Pair probabilities with actuals and sort descending
  const paired = actuals.map((actual, idx) => ({ actual, prob: probabilities[idx] }));
  paired.sort((a, b) => b.prob - a.prob);

  let numPos = 0;
  let numNeg = 0;
  for (const p of paired) {
    if (p.actual === 1) numPos++;
    else numNeg++;
  }

  if (numPos === 0 || numNeg === 0) return 0.5;

  let tp = 0;
  let fp = 0;
  let prevFp = 0;
  let prevTp = 0;
  let auc = 0;

  for (let i = 0; i < paired.length; i++) {
    if (paired[i].actual === 1) {
      tp++;
    } else {
      fp++;
    }

    // Trapezoidal rule integration
    const fpr = fp / numNeg;
    const tpr = tp / numPos;
    const prevFpr = prevFp / numNeg;
    const prevTpr = prevTp / numPos;

    auc += ((fpr - prevFpr) * (tpr + prevTpr)) / 2;
    prevFp = fp;
    prevTp = tp;
  }

  return Math.min(1.0, Math.max(0.0, Number(auc.toFixed(4))));
}

export function evaluatePredictions(
  actuals: number[],
  probabilities: number[],
  threshold = 0.5
): ClassificationMetrics {
  const cm = calculateConfusionMatrix(actuals, probabilities, threshold);
  const total = actuals.length || 1;

  const accuracy = (cm.tp + cm.tn) / total;

  // Class 1 (Claim) metrics
  const precision1 = cm.tp + cm.fp > 0 ? cm.tp / (cm.tp + cm.fp) : 0;
  const recall1 = cm.tp + cm.fn > 0 ? cm.tp / (cm.tp + cm.fn) : 0;
  const f1_1 = precision1 + recall1 > 0 ? (2 * precision1 * recall1) / (precision1 + recall1) : 0;

  // Class 0 (No Claim) metrics
  const precision0 = cm.tn + cm.fn > 0 ? cm.tn / (cm.tn + cm.fn) : 0;
  const recall0 = cm.tn + cm.fp > 0 ? cm.tn / (cm.tn + cm.fp) : 0;
  const f1_0 = precision0 + recall0 > 0 ? (2 * precision0 * recall0) / (precision0 + recall0) : 0;

  // Macro averages
  const macroPrecision = (precision1 + precision0) / 2;
  const macroRecall = (recall1 + recall0) / 2;
  const macroF1 = (f1_1 + f1_0) / 2;

  const rocAuc = calculateRocAuc(actuals, probabilities);

  return {
    accuracy: Number(accuracy.toFixed(4)),
    precision: Number(precision1.toFixed(4)),
    recall: Number(recall1.toFixed(4)),
    f1: Number(f1_1.toFixed(4)),
    macroPrecision: Number(macroPrecision.toFixed(4)),
    macroRecall: Number(macroRecall.toFixed(4)),
    macroF1: Number(macroF1.toFixed(4)),
    rocAuc,
    confusionMatrix: cm,
    threshold,
  };
}
