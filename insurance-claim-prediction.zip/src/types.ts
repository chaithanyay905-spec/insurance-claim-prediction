export interface RawPolicyRecord {
  policy_id: string;
  customer_age: string | number;
  gender: string;
  policy_type: string;
  vehicle_type: string;
  vehicle_age: string | number;
  annual_income: string | number;
  policy_tenure: string | number;
  premium_amount: string | number;
  coverage_amount: string | number;
  previous_claims: string | number;
  accident_history: string;
  driving_experience: string | number;
  vehicle_usage: string;
  claim_history: string;
  claim: string | number;
  [key: string]: any;
}

export interface CleanedPolicyRecord {
  policy_id: string;
  customer_age: number;
  gender: 'Male' | 'Female' | 'Other';
  policy_type: string;
  vehicle_type: string;
  vehicle_age: number;
  annual_income: number;
  policy_tenure: number;
  premium_amount: number;
  coverage_amount: number;
  previous_claims: number;
  accident_history: 'Yes' | 'No';
  driving_experience: number;
  vehicle_usage: 'Personal' | 'Commercial' | 'Mixed';
  claim_history: 'Yes' | 'No';
  claim: 0 | 1; // Normalized target: 0 = No Claim, 1 = Claim
  // Engineered attributes
  age_group: string;
  vehicle_age_group: string;
  premium_to_coverage_ratio: number;
  accident_indicator: number;
  claim_history_indicator: number;
  experience_group: string;
}

export interface FeatureStats {
  mean: number;
  std: number;
}

export interface PreprocessingMetadata {
  numericFeatures: string[];
  categoricalFeatures: { name: string; categories: string[] }[];
  featureNames: string[];
  scalers: Record<string, FeatureStats>;
  imputationValues: {
    medianNumerics: Record<string, number>;
    modeCategoricals: Record<string, string>;
  };
  uniquePolicyTypes: string[];
  uniqueVehicleTypes: string[];
  uniqueGenders: string[];
  uniqueVehicleUsages: string[];
}

export interface ConfusionMatrixData {
  tn: number;
  fp: number;
  fn: number;
  tp: number;
}

export interface ClassificationMetrics {
  accuracy: number;
  precision: number; // For claim class (1)
  recall: number; // For claim class (1)
  f1: number; // For claim class (1)
  macroPrecision: number;
  macroRecall: number;
  macroF1: number;
  rocAuc: number;
  confusionMatrix: ConfusionMatrixData;
  threshold: number;
}

export interface FeatureImportanceItem {
  feature: string;
  importance: number;
  description?: string;
}

export interface ModelTrainingResult {
  name: 'Logistic Regression' | 'Random Forest';
  metrics: ClassificationMetrics;
  testProbabilities: number[];
  testPredictions: number[];
  testActuals: number[];
  featureImportance: FeatureImportanceItem[];
  trainTimeMs: number;
  predict: (features: number[]) => { probability: number; prediction: number };
}

export interface PredictionInput {
  customer_age: number;
  gender: string;
  policy_type: string;
  vehicle_type: string;
  vehicle_age: number;
  annual_income: number;
  policy_tenure: number;
  premium_amount: number;
  coverage_amount: number;
  previous_claims: number;
  accident_history: 'Yes' | 'No';
  driving_experience: number;
  vehicle_usage: 'Personal' | 'Commercial' | 'Mixed';
  claim_history: 'Yes' | 'No';
}

export interface PredictionResult {
  predictedClass: 0 | 1;
  claimProbability: number;
  noClaimProbability: number;
  confidence: number;
  threshold: number;
  modelUsed: 'Logistic Regression' | 'Random Forest';
  input: PredictionInput;
  timestamp: string;
  topFactors: { factor: string; impact: 'increases risk' | 'decreases risk' | 'neutral'; description: string }[];
}

export interface DatasetStats {
  totalPolicies: number;
  totalClaims: number;
  totalNoClaims: number;
  claimRate: number;
  noClaimRate: number;
  avgPremium: number;
  avgCoverage: number;
  avgCustomerAge: number;
  avgPolicyTenure: number;
  avgDrivingExperience: number;
  avgVehicleAge: number;
}
