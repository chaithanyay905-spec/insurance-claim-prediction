import React from 'react';
import { Sliders, RotateCcw, HelpCircle } from 'lucide-react';
import { ClassificationMetrics } from '../types';

interface ThresholdSliderProps {
  threshold: number;
  onChangeThreshold: (val: number) => void;
  metrics: ClassificationMetrics;
  modelName: string;
}

export const ThresholdSlider: React.FC<ThresholdSliderProps> = ({
  threshold,
  onChangeThreshold,
  metrics,
  modelName,
}) => {
  const cm = metrics.confusionMatrix;
  const predClaimCount = cm.tp + cm.fp;
  const predNoClaimCount = cm.tn + cm.fn;
  const total = predClaimCount + predNoClaimCount || 1;

  return (
    <div id="k8m4q1" className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 pb-2 border-b border-slate-100">
        <div>
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-cyan-600" />
            <h3 className="text-sm font-semibold text-slate-900">
              Interactive Classification Threshold Analysis
            </h3>
          </div>
          <p className="text-xs text-slate-500">
            Tune probability cutoff P(claim = 1) &ge; &tau; to explore precision/recall trade-offs
          </p>
        </div>

        <button
          onClick={() => onChangeThreshold(0.5)}
          className="flex items-center gap-1.5 px-2.5 py-1 text-xs text-slate-600 hover:text-cyan-700 hover:bg-slate-100 rounded-md border border-slate-200 transition-colors"
        >
          <RotateCcw className="w-3 h-3" />
          Reset to 0.50
        </button>
      </div>

      {/* Slider Control */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs font-semibold">
          <span className="text-slate-700">Classification Threshold:</span>
          <span className="px-2.5 py-0.5 bg-cyan-50 border border-cyan-200 text-cyan-900 rounded-md text-sm font-bold">
            {threshold.toFixed(2)}
          </span>
        </div>

        <input
          id="slider-classification-threshold"
          type="range"
          min="0.10"
          max="0.90"
          step="0.02"
          value={threshold}
          onChange={(e) => onChangeThreshold(parseFloat(e.target.value))}
          className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-cyan-700"
        />

        <div className="flex justify-between text-[10px] text-slate-400 font-medium">
          <span>0.10 (High Recall / Aggressive)</span>
          <span>0.50 (Standard Neutral)</span>
          <span>0.90 (High Precision / Conservative)</span>
        </div>
      </div>

      {/* Live impact metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
        <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/80">
          <div className="text-[11px] text-slate-500">Predicted Claims</div>
          <div className="text-sm font-bold text-slate-900 mt-0.5">
            {predClaimCount} ({Math.round((predClaimCount / total) * 100)}%)
          </div>
        </div>

        <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/80">
          <div className="text-[11px] text-slate-500">Predicted No-Claims</div>
          <div className="text-sm font-bold text-slate-900 mt-0.5">
            {predNoClaimCount} ({Math.round((predNoClaimCount / total) * 100)}%)
          </div>
        </div>

        <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/80">
          <div className="text-[11px] text-slate-500">Precision (Claim)</div>
          <div className="text-sm font-bold text-cyan-800 mt-0.5">
            {(metrics.precision * 100).toFixed(1)}%
          </div>
        </div>

        <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/80">
          <div className="text-[11px] text-slate-500">Recall / Sensitivity</div>
          <div className="text-sm font-bold text-cyan-800 mt-0.5">
            {(metrics.recall * 100).toFixed(1)}%
          </div>
        </div>
      </div>

      <div className="text-[11px] text-slate-400 bg-slate-50/50 p-2.5 rounded-lg">
        * Note: Threshold tuning dynamically shifts the operating point along the model's ROC curve. It does not represent an underwriting rule or insurance policy decision.
      </div>
    </div>
  );
};
