import React, { useState } from 'react';
import { PredictionInput } from '../types';
import { Sparkles, RefreshCw, User, Shield, Car, History } from 'lucide-react';

interface ClaimPredictionFormProps {
  initialValues?: Partial<PredictionInput>;
  onPredict: (input: PredictionInput, model: 'Logistic Regression' | 'Random Forest') => void;
  uniquePolicyTypes: string[];
  uniqueVehicleTypes: string[];
  uniqueGenders: string[];
  uniqueVehicleUsages: string[];
  selectedModel: 'Logistic Regression' | 'Random Forest';
  onChangeModel: (model: 'Logistic Regression' | 'Random Forest') => void;
  isPredicting?: boolean;
}

const PRESETS: { name: string; description: string; data: PredictionInput }[] = [
  {
    name: 'Safe Experienced Driver',
    description: '45 yrs, 20 yrs exp, no previous claims, personal vehicle',
    data: {
      customer_age: 45,
      gender: 'Female',
      policy_type: 'Comprehensive',
      vehicle_type: 'Sedan',
      vehicle_age: 3,
      annual_income: 82000,
      policy_tenure: 7,
      premium_amount: 1150,
      coverage_amount: 50000,
      previous_claims: 0,
      accident_history: 'No',
      driving_experience: 22,
      vehicle_usage: 'Personal',
      claim_history: 'No',
    },
  },
  {
    name: 'High-Risk Novice Driver',
    description: '21 yrs, 1 yr exp, 2 previous claims, accident history',
    data: {
      customer_age: 21,
      gender: 'Male',
      policy_type: 'Standard',
      vehicle_type: 'Truck',
      vehicle_age: 12,
      annual_income: 38000,
      policy_tenure: 1,
      premium_amount: 2400,
      coverage_amount: 40000,
      previous_claims: 2,
      accident_history: 'Yes',
      driving_experience: 1,
      vehicle_usage: 'Personal',
      claim_history: 'Yes',
    },
  },
  {
    name: 'Commercial Fleet Vehicle',
    description: '38 yrs, commercial usage, mixed tenure, 1 claim',
    data: {
      customer_age: 38,
      gender: 'Male',
      policy_type: 'Comprehensive',
      vehicle_type: 'SUV',
      vehicle_age: 6,
      annual_income: 95000,
      policy_tenure: 3,
      premium_amount: 2100,
      coverage_amount: 75000,
      previous_claims: 1,
      accident_history: 'Yes',
      driving_experience: 14,
      vehicle_usage: 'Commercial',
      claim_history: 'Yes',
    },
  },
  {
    name: 'Average Commuter',
    description: '35 yrs, 12 yrs exp, clean record, standard sedan',
    data: {
      customer_age: 35,
      gender: 'Male',
      policy_type: 'Standard',
      vehicle_type: 'Sedan',
      vehicle_age: 5,
      annual_income: 65000,
      policy_tenure: 4,
      premium_amount: 1350,
      coverage_amount: 45000,
      previous_claims: 0,
      accident_history: 'No',
      driving_experience: 12,
      vehicle_usage: 'Personal',
      claim_history: 'No',
    },
  },
];

export const ClaimPredictionForm: React.FC<ClaimPredictionFormProps> = ({
  onPredict,
  uniquePolicyTypes,
  uniqueVehicleTypes,
  uniqueGenders,
  uniqueVehicleUsages,
  selectedModel,
  onChangeModel,
  isPredicting = false,
}) => {
  const [formData, setFormData] = useState<PredictionInput>(PRESETS[0].data);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const policyOptions = uniquePolicyTypes.length ? uniquePolicyTypes : ['Comprehensive', 'Standard', 'Third-Party', 'Premium'];
  const vehicleOptions = uniqueVehicleTypes.length ? uniqueVehicleTypes : ['Sedan', 'SUV', 'Hatchback', 'Truck', 'Luxury'];
  const genderOptions = uniqueGenders.length ? uniqueGenders : ['Male', 'Female'];
  const usageOptions = uniqueVehicleUsages.length ? uniqueVehicleUsages : ['Personal', 'Commercial', 'Mixed'];

  const handleChange = (field: keyof PredictionInput, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors((prev) => {
        const next = { ...prev };
        delete next[field];
        return next;
      });
    }
  };

  const applyPreset = (preset: PredictionInput) => {
    setFormData(preset);
    setErrors({});
  };

  const validate = (): boolean => {
    const errs: Record<string, string> = {};
    if (formData.customer_age < 18 || formData.customer_age > 100) {
      errs.customer_age = 'Age must be between 18 and 100';
    }
    if (formData.vehicle_age < 0 || formData.vehicle_age > 30) {
      errs.vehicle_age = 'Vehicle age must be between 0 and 30';
    }
    if (formData.annual_income < 1000) {
      errs.annual_income = 'Income must be greater than $1,000';
    }
    if (formData.premium_amount < 100) {
      errs.premium_amount = 'Premium must be at least $100';
    }
    if (formData.coverage_amount < 1000) {
      errs.coverage_amount = 'Coverage must be at least $1,000';
    }
    if (formData.driving_experience < 0 || formData.driving_experience > 70) {
      errs.driving_experience = 'Experience must be 0 to 70';
    }
    if (formData.driving_experience > formData.customer_age - 16) {
      errs.driving_experience = 'Driving experience cannot exceed (Age - 16)';
    }

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    onPredict(formData, selectedModel);
  };

  return (
    <form id="claim-prediction-form" onSubmit={handleSubmit} className="space-y-6">
      {/* Top controls: Presets & Model Selection */}
      <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/80 space-y-3">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <span className="text-xs font-semibold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-cyan-600" />
            Quick Presets
          </span>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500 font-medium">Model:</span>
            <div className="inline-flex rounded-lg border border-slate-300 p-0.5 bg-white text-xs">
              <button
                type="button"
                id="btn-select-model-rf"
                onClick={() => onChangeModel('Random Forest')}
                className={`px-3 py-1 rounded-md font-medium transition-all ${
                  selectedModel === 'Random Forest'
                    ? 'bg-cyan-700 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Random Forest
              </button>
              <button
                type="button"
                id="btn-select-model-lr"
                onClick={() => onChangeModel('Logistic Regression')}
                className={`px-3 py-1 rounded-md font-medium transition-all ${
                  selectedModel === 'Logistic Regression'
                    ? 'bg-cyan-700 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Logistic Regression
              </button>
            </div>
          </div>
        </div>

        {/* Preset Chips */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
          {PRESETS.map((p, idx) => (
            <button
              key={idx}
              type="button"
              id={`preset-btn-${idx}`}
              onClick={() => applyPreset(p.data)}
              className="text-left p-2.5 rounded-lg bg-white border border-slate-200 hover:border-cyan-500 hover:bg-cyan-50/40 transition-colors shadow-xs group"
            >
              <div className="text-xs font-semibold text-slate-800 group-hover:text-cyan-900">
                {p.name}
              </div>
              <div className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">{p.description}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Structured Sections */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* 1. Customer Information */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
            <div className="w-7 h-7 rounded-lg bg-slate-100 flex items-center justify-center text-slate-700">
              <User className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-semibold text-slate-900">Customer Information</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="input-customer-age" className="block text-xs font-medium text-slate-700 mb-1">
                Customer Age (years)
              </label>
              <input
                id="input-customer-age"
                type="number"
                min="18"
                max="95"
                value={formData.customer_age}
                onChange={(e) => handleChange('customer_age', Number(e.target.value))}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 outline-none"
                required
              />
              {errors.customer_age && (
                <p className="text-[11px] text-rose-600 mt-1">{errors.customer_age}</p>
              )}
            </div>

            <div>
              <label htmlFor="input-gender" className="block text-xs font-medium text-slate-700 mb-1">
                Gender
              </label>
              <select
                id="input-gender"
                value={formData.gender}
                onChange={(e) => handleChange('gender', e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 outline-none bg-white"
              >
                {genderOptions.map((g) => (
                  <option key={g} value={g}>
                    {g}
                  </option>
                ))}
              </select>
            </div>

            <div className="sm:col-span-2">
              <label htmlFor="input-annual-income" className="block text-xs font-medium text-slate-700 mb-1">
                Annual Income ($)
              </label>
              <input
                id="input-annual-income"
                type="number"
                step="1000"
                min="5000"
                max="500000"
                value={formData.annual_income}
                onChange={(e) => handleChange('annual_income', Number(e.target.value))}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 outline-none"
                required
              />
              {errors.annual_income && (
                <p className="text-[11px] text-rose-600 mt-1">{errors.annual_income}</p>
              )}
            </div>
          </div>
        </div>

        {/* 2. Policy Information */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
            <div className="w-7 h-7 rounded-lg bg-slate-100 flex items-center justify-center text-slate-700">
              <Shield className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-semibold text-slate-900">Policy Information</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="input-policy-type" className="block text-xs font-medium text-slate-700 mb-1">
                Policy Type
              </label>
              <select
                id="input-policy-type"
                value={formData.policy_type}
                onChange={(e) => handleChange('policy_type', e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 outline-none bg-white"
              >
                {policyOptions.map((p) => (
                  <option key={p} value={p}>
                    {p}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="input-policy-tenure" className="block text-xs font-medium text-slate-700 mb-1">
                Policy Tenure (years)
              </label>
              <input
                id="input-policy-tenure"
                type="number"
                min="0"
                max="30"
                value={formData.policy_tenure}
                onChange={(e) => handleChange('policy_tenure', Number(e.target.value))}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 outline-none"
                required
              />
            </div>

            <div>
              <label htmlFor="input-premium-amount" className="block text-xs font-medium text-slate-700 mb-1">
                Annual Premium ($)
              </label>
              <input
                id="input-premium-amount"
                type="number"
                min="100"
                max="10000"
                value={formData.premium_amount}
                onChange={(e) => handleChange('premium_amount', Number(e.target.value))}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 outline-none"
                required
              />
              {errors.premium_amount && (
                <p className="text-[11px] text-rose-600 mt-1">{errors.premium_amount}</p>
              )}
            </div>

            <div>
              <label htmlFor="input-coverage-amount" className="block text-xs font-medium text-slate-700 mb-1">
                Coverage Amount ($)
              </label>
              <input
                id="input-coverage-amount"
                type="number"
                step="5000"
                min="5000"
                max="200000"
                value={formData.coverage_amount}
                onChange={(e) => handleChange('coverage_amount', Number(e.target.value))}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 outline-none"
                required
              />
              {errors.coverage_amount && (
                <p className="text-[11px] text-rose-600 mt-1">{errors.coverage_amount}</p>
              )}
            </div>
          </div>
        </div>

        {/* 3. Vehicle Information */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
            <div className="w-7 h-7 rounded-lg bg-slate-100 flex items-center justify-center text-slate-700">
              <Car className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-semibold text-slate-900">Vehicle Information</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="input-vehicle-type" className="block text-xs font-medium text-slate-700 mb-1">
                Vehicle Type
              </label>
              <select
                id="input-vehicle-type"
                value={formData.vehicle_type}
                onChange={(e) => handleChange('vehicle_type', e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 outline-none bg-white"
              >
                {vehicleOptions.map((v) => (
                  <option key={v} value={v}>
                    {v}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="input-vehicle-age" className="block text-xs font-medium text-slate-700 mb-1">
                Vehicle Age (years)
              </label>
              <input
                id="input-vehicle-age"
                type="number"
                min="0"
                max="25"
                value={formData.vehicle_age}
                onChange={(e) => handleChange('vehicle_age', Number(e.target.value))}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 outline-none"
                required
              />
            </div>

            <div>
              <label htmlFor="input-vehicle-usage" className="block text-xs font-medium text-slate-700 mb-1">
                Vehicle Usage
              </label>
              <select
                id="input-vehicle-usage"
                value={formData.vehicle_usage}
                onChange={(e) => handleChange('vehicle_usage', e.target.value as any)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 outline-none bg-white"
              >
                {usageOptions.map((u) => (
                  <option key={u} value={u}>
                    {u}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="input-driving-experience" className="block text-xs font-medium text-slate-700 mb-1">
                Driving Experience (years)
              </label>
              <input
                id="input-driving-experience"
                type="number"
                min="0"
                max="60"
                value={formData.driving_experience}
                onChange={(e) => handleChange('driving_experience', Number(e.target.value))}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 outline-none"
                required
              />
              {errors.driving_experience && (
                <p className="text-[11px] text-rose-600 mt-1">{errors.driving_experience}</p>
              )}
            </div>
          </div>
        </div>

        {/* 4. History */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
            <div className="w-7 h-7 rounded-lg bg-slate-100 flex items-center justify-center text-slate-700">
              <History className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-semibold text-slate-900">Historical Risk Indicators</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="input-previous-claims" className="block text-xs font-medium text-slate-700 mb-1">
                Previous Claims Count
              </label>
              <input
                id="input-previous-claims"
                type="number"
                min="0"
                max="10"
                value={formData.previous_claims}
                onChange={(e) => handleChange('previous_claims', Number(e.target.value))}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 outline-none"
                required
              />
            </div>

            <div>
              <label htmlFor="input-accident-history" className="block text-xs font-medium text-slate-700 mb-1">
                Prior Accident History
              </label>
              <select
                id="input-accident-history"
                value={formData.accident_history}
                onChange={(e) => handleChange('accident_history', e.target.value as any)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 outline-none bg-white"
              >
                <option value="No">No</option>
                <option value="Yes">Yes</option>
              </select>
            </div>

            <div className="sm:col-span-2">
              <label htmlFor="input-claim-history" className="block text-xs font-medium text-slate-700 mb-1">
                Claim History Indicator
              </label>
              <select
                id="input-claim-history"
                value={formData.claim_history}
                onChange={(e) => handleChange('claim_history', e.target.value as any)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 outline-none bg-white"
              >
                <option value="No">No</option>
                <option value="Yes">Yes</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Submit Button */}
      <div className="flex items-center justify-end gap-3 pt-2">
        <button
          type="button"
          onClick={() => applyPreset(PRESETS[0].data)}
          className="px-4 py-2.5 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 text-sm font-medium transition-colors"
        >
          Reset to Default
        </button>

        <button
          type="submit"
          id="q7x4m1"
          disabled={isPredicting}
          className="flex items-center gap-2 px-6 py-2.5 rounded-lg bg-cyan-700 hover:bg-cyan-800 active:bg-cyan-900 text-white font-semibold text-sm shadow-sm transition-all"
        >
          {isPredicting ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin" />
              Computing Prediction...
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4" />
              Predict Claim Likelihood
            </>
          )}
        </button>
      </div>
    </form>
  );
};
