import React from 'react';
import { PredictionResult as PredictionResultType } from '../types';
import { ShieldCheck, AlertCircle, TrendingUp, Info, HelpCircle } from 'lucide-react';
import { DisclaimerBanner } from './DisclaimerBanner';

interface PredictionResultProps {
  result: PredictionResultType;
}

export const PredictionResult: React.FC<PredictionResultProps> = ({ result }) => {
  const isClaim = result.predictedClass === 1;
  const claimPct = Math.round(result.claimProbability * 100);
  const noClaimPct = Math.round(result.noClaimProbability * 100);

  return (
    <div id="m4x8q2" className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-6">
      {/* Header status badge & Title */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
        <div className="flex items-center gap-3">
          <div
            className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
              isClaim ? 'bg-rose-100 text-rose-700' : 'bg-emerald-100 text-emerald-700'
            }`}
          >
            {isClaim ? <AlertCircle className="w-6 h-6" /> : <ShieldCheck className="w-6 h-6" />}
          </div>

          <div>
            <div className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Claim Prediction Outcome
            </div>
            <h3
              id={isClaim ? 'n7c3v5' : 'x5m9q1'}
              className={`text-xl font-bold tracking-tight ${
                isClaim ? 'text-rose-700' : 'text-emerald-700'
              }`}
            >
              {isClaim ? 'Likely to Result in a Claim' : 'Likely No Claim'}
            </h3>
          </div>
        </div>

        <div className="flex items-center gap-2 self-end sm:self-auto">
          <span className="text-xs text-slate-500 font-medium">Model:</span>
          <span className="px-2.5 py-1 bg-slate-100 text-slate-800 rounded-md text-xs font-semibold">
            {result.modelUsed}
          </span>
        </div>
      </div>

      {/* Probability Progress Visualization */}
      <div id="x8q3m5" className="space-y-3 bg-slate-50 p-5 rounded-xl border border-slate-200/80">
        <div className="flex items-center justify-between text-sm font-semibold">
          <span className="text-slate-800 flex items-center gap-1.5">
            Claim Probability
            <span className="text-xs font-normal text-slate-500">(Threshold: {result.threshold})</span>
          </span>
          <span className={`text-base font-bold ${isClaim ? 'text-rose-700' : 'text-slate-700'}`}>
            {claimPct}%
          </span>
        </div>

        {/* Dual Stacked Progress Bar */}
        <div className="h-4 w-full bg-slate-200 rounded-full overflow-hidden flex">
          <div
            className="bg-rose-500 h-full transition-all duration-500 rounded-l-full"
            style={{ width: `${claimPct}%` }}
            title={`Claim Probability: ${claimPct}%`}
          />
          <div
            className="bg-emerald-500 h-full transition-all duration-500 rounded-r-full"
            style={{ width: `${noClaimPct}%` }}
            title={`No-Claim Probability: ${noClaimPct}%`}
          />
        </div>

        <div className="flex items-center justify-between text-xs text-slate-500 pt-1 font-medium">
          <span className="text-rose-700 font-semibold">Claim Likelihood: {claimPct}%</span>
          <span id="j4m7v2" className="text-emerald-700 font-semibold">
            No Claim Probability: {noClaimPct}%
          </span>
        </div>
      </div>

      {/* Analytical Metadata Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
          <div className="text-[11px] font-medium text-slate-500">Prediction Confidence</div>
          <div className="text-sm font-bold text-slate-900 mt-0.5">
            {Math.round(result.confidence * 100)}%
          </div>
        </div>

        <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
          <div className="text-[11px] font-medium text-slate-500">Decision Threshold</div>
          <div className="text-sm font-bold text-slate-900 mt-0.5">{result.threshold}</div>
        </div>

        <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
          <div className="text-[11px] font-medium text-slate-500">Evaluation Timestamp</div>
          <div className="text-sm font-bold text-slate-900 mt-0.5">{result.timestamp}</div>
        </div>

        <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
          <div className="text-[11px] font-medium text-slate-500">Classification Mode</div>
          <div className="text-sm font-bold text-slate-900 mt-0.5">Statistical ML</div>
        </div>
      </div>

      {/* Influential Factors Breakdown */}
      {result.topFactors && result.topFactors.length > 0 && (
        <div className="space-y-2.5">
          <h4 className="text-xs font-semibold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
            <TrendingUp className="w-3.5 h-3.5 text-cyan-600" />
            Key Profile Risk Factors
          </h4>
          <div className="space-y-2">
            {result.topFactors.map((f, i) => (
              <div
                key={i}
                className="p-3 rounded-lg border border-slate-100 bg-slate-50/60 flex items-start justify-between gap-3 text-xs"
              >
                <div>
                  <span className="font-semibold text-slate-900">{f.factor}:</span>{' '}
                  <span className="text-slate-600">{f.description}</span>
                </div>
                <span
                  className={`px-2 py-0.5 rounded-full text-[10px] font-semibold shrink-0 uppercase tracking-wide ${
                    f.impact === 'increases risk'
                      ? 'bg-rose-50 text-rose-700 border border-rose-200'
                      : f.impact === 'decreases risk'
                      ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                      : 'bg-slate-100 text-slate-700'
                  }`}
                >
                  {f.impact}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Mandatory Disclaimer */}
      <DisclaimerBanner compact />
    </div>
  );
};
