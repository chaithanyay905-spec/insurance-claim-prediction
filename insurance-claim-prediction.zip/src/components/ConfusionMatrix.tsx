import React from 'react';
import { ConfusionMatrixData } from '../types';

interface ConfusionMatrixProps {
  matrix: ConfusionMatrixData;
  modelName: string;
  threshold: number;
}

export const ConfusionMatrix: React.FC<ConfusionMatrixProps> = ({ matrix, modelName, threshold }) => {
  const total = matrix.tn + matrix.fp + matrix.fn + matrix.tp || 1;
  const actualNoClaim = matrix.tn + matrix.fp;
  const actualClaim = matrix.fn + matrix.tp;
  const predNoClaim = matrix.tn + matrix.fn;
  const predClaim = matrix.fp + matrix.tp;

  return (
    <div id="confusion-matrix-container" className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 pb-2 border-b border-slate-100">
        <div>
          <h3 className="text-sm font-semibold text-slate-900">
            Binary Confusion Matrix ({modelName})
          </h3>
          <p className="text-xs text-slate-500">
            Independent test evaluation at decision threshold <strong>{threshold.toFixed(2)}</strong> (Total: {total} records)
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 font-medium">
            Test Size: {total}
          </span>
        </div>
      </div>

      {/* Grid Layout of Matrix */}
      <div className="overflow-x-auto min-w-0">
        <div className="min-w-[360px] max-w-lg mx-auto">
          {/* Column Header */}
          <div className="grid grid-cols-3 text-center text-xs font-semibold text-slate-600 mb-1">
            <div className="text-left text-slate-400 font-normal">Actual \ Predicted</div>
            <div className="p-2 bg-slate-100 rounded-t-lg">Predicted: No Claim (0)</div>
            <div className="p-2 bg-slate-100 rounded-t-lg">Predicted: Claim (1)</div>
          </div>

          {/* Row 1: Actual No Claim */}
          <div className="grid grid-cols-3 text-center gap-1 mb-1">
            <div className="flex items-center justify-start p-2 text-xs font-semibold text-slate-700 bg-slate-100 rounded-l-lg">
              Actual: No Claim (0)
            </div>

            {/* True Negative */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg flex flex-col justify-center">
              <span className="text-[11px] font-medium text-slate-500">True Negative (TN)</span>
              <span className="text-xl font-bold text-slate-900 mt-1">{matrix.tn}</span>
              <span className="text-[10px] text-slate-400 mt-0.5">
                {actualNoClaim > 0 ? `${Math.round((matrix.tn / actualNoClaim) * 100)}% of actual 0s` : ''}
              </span>
            </div>

            {/* False Positive (Type I Error) */}
            <div className="p-4 bg-rose-50/70 border border-rose-200 rounded-lg flex flex-col justify-center">
              <span className="text-[11px] font-semibold text-rose-700">False Positive (FP)</span>
              <span className="text-xl font-bold text-rose-900 mt-1">{matrix.fp}</span>
              <span className="text-[10px] text-rose-600/80 mt-0.5">Type I Error</span>
            </div>
          </div>

          {/* Row 2: Actual Claim */}
          <div className="grid grid-cols-3 text-center gap-1">
            <div className="flex items-center justify-start p-2 text-xs font-semibold text-slate-700 bg-slate-100 rounded-l-lg">
              Actual: Claim (1)
            </div>

            {/* False Negative (Type II Error) */}
            <div className="p-4 bg-amber-50/70 border border-amber-200 rounded-lg flex flex-col justify-center">
              <span className="text-[11px] font-semibold text-amber-700">False Negative (FN)</span>
              <span className="text-xl font-bold text-amber-900 mt-1">{matrix.fn}</span>
              <span className="text-[10px] text-amber-600/80 mt-0.5">Missed Claims (Type II)</span>
            </div>

            {/* True Positive */}
            <div className="p-4 bg-emerald-50/70 border border-emerald-200 rounded-lg flex flex-col justify-center">
              <span className="text-[11px] font-semibold text-emerald-700">True Positive (TP)</span>
              <span className="text-xl font-bold text-emerald-900 mt-1">{matrix.tp}</span>
              <span className="text-[10px] text-emerald-600/80 mt-0.5">
                {actualClaim > 0 ? `${Math.round((matrix.tp / actualClaim) * 100)}% of actual 1s` : ''}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Summary Rates */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-2 border-t border-slate-100 text-xs">
        <div className="p-2.5 bg-slate-50 rounded-lg">
          <div className="text-[11px] text-slate-500">Correctly Classified</div>
          <div className="text-sm font-bold text-slate-900 mt-0.5">
            {matrix.tp + matrix.tn} / {total} ({Math.round(((matrix.tp + matrix.tn) / total) * 100)}%)
          </div>
        </div>

        <div className="p-2.5 bg-slate-50 rounded-lg">
          <div className="text-[11px] text-slate-500">Misclassified Total</div>
          <div className="text-sm font-bold text-rose-700 mt-0.5">
            {matrix.fp + matrix.fn} / {total} ({Math.round(((matrix.fp + matrix.fn) / total) * 100)}%)
          </div>
        </div>

        <div className="p-2.5 bg-slate-50 rounded-lg">
          <div className="text-[11px] text-slate-500">Specificity (TN Rate)</div>
          <div className="text-sm font-bold text-slate-900 mt-0.5">
            {actualNoClaim > 0 ? `${Math.round((matrix.tn / actualNoClaim) * 100)}%` : 'N/A'}
          </div>
        </div>

        <div className="p-2.5 bg-slate-50 rounded-lg">
          <div className="text-[11px] text-slate-500">Sensitivity / Recall</div>
          <div className="text-sm font-bold text-emerald-700 mt-0.5">
            {actualClaim > 0 ? `${Math.round((matrix.tp / actualClaim) * 100)}%` : 'N/A'}
          </div>
        </div>
      </div>
    </div>
  );
};
