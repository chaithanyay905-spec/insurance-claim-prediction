import React from 'react';
import { AlertTriangle } from 'lucide-react';

interface DisclaimerBannerProps {
  compact?: boolean;
}

export const DisclaimerBanner: React.FC<DisclaimerBannerProps> = ({ compact = false }) => {
  if (compact) {
    return (
      <div
        id="insurance-disclaimer-compact"
        className="p-3 bg-amber-50/80 border border-amber-200 rounded-lg text-xs text-amber-900 flex items-start gap-2.5"
      >
        <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
        <p className="leading-relaxed">
          <strong className="font-semibold">Analytical Disclaimer:</strong> This application provides a machine-learning prediction based on historical dataset patterns. It is not an insurance underwriting decision, claim approval/denial system, fraud detector, or guarantee of future claim behavior.
        </p>
      </div>
    );
  }

  return (
    <div
      id="insurance-disclaimer-banner"
      className="p-4 bg-amber-50/90 border border-amber-200/90 rounded-xl text-xs sm:text-sm text-amber-950 flex items-start gap-3 shadow-xs"
    >
      <div className="w-7 h-7 rounded-lg bg-amber-100 flex items-center justify-center text-amber-700 shrink-0 mt-0.5">
        <AlertTriangle className="w-4 h-4" />
      </div>
      <div className="space-y-1">
        <h4 className="font-semibold text-amber-900 text-xs sm:text-sm">
          Insurance Underwriting & Regulatory Notice
        </h4>
        <p className="text-amber-800 text-xs leading-relaxed">
          <strong>Disclaimer:</strong> This application provides a machine-learning prediction based on patterns in historical data. It is not an insurance underwriting decision, claim approval/denial system, fraud detector, or guarantee of future claim behavior. All estimates are strictly statistical inferences intended for decision-support and demonstration.
        </p>
      </div>
    </div>
  );
};
