import React from 'react';
import { ModelTrainingResult } from '../types';
import { Sparkles, CheckCircle, Award } from 'lucide-react';

interface ModelMetricsTableProps {
  logisticRegression: ModelTrainingResult;
  randomForest: ModelTrainingResult;
  bestModelName: 'Logistic Regression' | 'Random Forest';
}

export const ModelMetricsTable: React.FC<ModelMetricsTableProps> = ({
  logisticRegression,
  randomForest,
  bestModelName,
}) => {
  const lrM = logisticRegression.metrics;
  const rfM = randomForest.metrics;

  const getHighlightClass = (valA: number, valB: number) => {
    if (valA > valB) return 'font-bold text-emerald-700 bg-emerald-50/50';
    if (valA < valB) return 'text-slate-600';
    return 'text-slate-700';
  };

  return (
    <div id="q6m2x9" className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 pb-2 border-b border-slate-100">
        <div>
          <h3 className="text-sm font-semibold text-slate-900">
            Model Evaluation & Benchmark Comparison
          </h3>
          <p className="text-xs text-slate-500">
            Independent evaluation conducted on identical 20% stratified test partition
          </p>
        </div>

        <div className="flex items-center gap-1.5 px-3 py-1 bg-emerald-50 border border-emerald-200 rounded-full text-xs font-semibold text-emerald-800">
          <Award className="w-3.5 h-3.5 text-emerald-600" />
          <span id="v8m3q5">Best Model: {bestModelName}</span>
        </div>
      </div>

      <div className="overflow-x-auto min-w-0">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase font-semibold tracking-wider">
              <th className="py-3 px-4">Model Algorithm</th>
              <th className="py-3 px-4 text-center">Accuracy</th>
              <th className="py-3 px-4 text-center">Precision (Claim)</th>
              <th className="py-3 px-4 text-center">Recall (Claim)</th>
              <th className="py-3 px-4 text-center">F1 Score</th>
              <th className="py-3 px-4 text-center">ROC-AUC</th>
              <th className="py-3 px-4 text-center">Train Time</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {/* Logistic Regression */}
            <tr className="hover:bg-slate-50/60 transition-colors">
              <td className="py-3.5 px-4 font-semibold text-slate-900 flex items-center gap-2">
                Logistic Regression
                {bestModelName === 'Logistic Regression' && (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-cyan-100 text-cyan-800">
                    CHAMPION
                  </span>
                )}
              </td>
              <td className={`py-3.5 px-4 text-center ${getHighlightClass(lrM.accuracy, rfM.accuracy)}`}>
                {(lrM.accuracy * 100).toFixed(1)}%
              </td>
              <td className={`py-3.5 px-4 text-center ${getHighlightClass(lrM.precision, rfM.precision)}`}>
                {(lrM.precision * 100).toFixed(1)}%
              </td>
              <td className={`py-3.5 px-4 text-center ${getHighlightClass(lrM.recall, rfM.recall)}`}>
                {(lrM.recall * 100).toFixed(1)}%
              </td>
              <td className={`py-3.5 px-4 text-center ${getHighlightClass(lrM.f1, rfM.f1)}`}>
                {(lrM.f1 * 100).toFixed(1)}%
              </td>
              <td className={`py-3.5 px-4 text-center ${getHighlightClass(lrM.rocAuc, rfM.rocAuc)}`}>
                {lrM.rocAuc.toFixed(3)}
              </td>
              <td className="py-3.5 px-4 text-center text-slate-500 font-mono">
                {logisticRegression.trainTimeMs} ms
              </td>
            </tr>

            {/* Random Forest */}
            <tr className="hover:bg-slate-50/60 transition-colors">
              <td className="py-3.5 px-4 font-semibold text-slate-900 flex items-center gap-2">
                Random Forest (20 Trees)
                {bestModelName === 'Random Forest' && (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-cyan-100 text-cyan-800">
                    CHAMPION
                  </span>
                )}
              </td>
              <td className={`py-3.5 px-4 text-center ${getHighlightClass(rfM.accuracy, lrM.accuracy)}`}>
                {(rfM.accuracy * 100).toFixed(1)}%
              </td>
              <td className={`py-3.5 px-4 text-center ${getHighlightClass(rfM.precision, lrM.precision)}`}>
                {(rfM.precision * 100).toFixed(1)}%
              </td>
              <td className={`py-3.5 px-4 text-center ${getHighlightClass(rfM.recall, lrM.recall)}`}>
                {(rfM.recall * 100).toFixed(1)}%
              </td>
              <td className={`py-3.5 px-4 text-center ${getHighlightClass(rfM.f1, lrM.f1)}`}>
                {(rfM.f1 * 100).toFixed(1)}%
              </td>
              <td className={`py-3.5 px-4 text-center ${getHighlightClass(rfM.rocAuc, lrM.rocAuc)}`}>
                {rfM.rocAuc.toFixed(3)}
              </td>
              <td className="py-3.5 px-4 text-center text-slate-500 font-mono">
                {randomForest.trainTimeMs} ms
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <div className="text-[11px] text-slate-500 bg-slate-50 p-3 rounded-lg flex items-center justify-between">
        <span>
          <strong>Selection Logic:</strong> Model champion is selected using class-1 weighted F1 score and ROC-AUC rather than raw accuracy, reflecting real-world insurance claim imbalance.
        </span>
      </div>
    </div>
  );
};
