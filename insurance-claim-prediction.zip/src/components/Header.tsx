import React from 'react';
import { Menu, FileDown, Sparkles, Check, Database, Loader2 } from 'lucide-react';
import { DatasetStats } from '../types';

interface HeaderProps {
  onToggleSidebar: () => void;
  datasetLoaded: boolean;
  modelTrained: boolean;
  bestModelName: string;
  stats: DatasetStats;
  onDownloadReport: () => void;
  isGeneratingReport: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  onToggleSidebar,
  datasetLoaded,
  modelTrained,
  bestModelName,
  stats,
  onDownloadReport,
  isGeneratingReport,
}) => {
  return (
    <header
      id="app-header"
      className="sticky top-0 z-30 bg-white/95 backdrop-blur-xs border-b border-slate-200 px-4 sm:px-6 py-3.5 flex items-center justify-between gap-4"
    >
      {/* Left: Mobile Menu & Breadcrumb */}
      <div className="flex items-center gap-3 min-w-0">
        <button
          id="btn-sidebar-toggle"
          onClick={onToggleSidebar}
          className="lg:hidden p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors"
          aria-label="Toggle navigation menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="min-w-0">
          <h1 className="text-base sm:text-lg font-bold text-slate-900 truncate tracking-tight">
            Insurance Claim Prediction
          </h1>
          <p className="text-xs text-slate-500 hidden sm:block">
            In-Browser Machine Learning Classification & Actuarial Exploration
          </p>
        </div>
      </div>

      {/* Right: Operational Status Badges & Download Report */}
      <div className="flex items-center gap-2 sm:gap-3 shrink-0">
        {/* Dataset Status */}
        <div className="hidden md:flex items-center gap-1.5 px-2.5 py-1 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-600 font-medium">
          <Database className="w-3.5 h-3.5 text-cyan-600" />
          <span>{datasetLoaded ? `${stats.totalPolicies} Policies` : 'Loading CSV...'}</span>
        </div>

        {/* Claim Rate Chip */}
        {datasetLoaded && (
          <div className="hidden xl:flex items-center gap-1.5 px-2.5 py-1 bg-cyan-50 border border-cyan-200 text-cyan-800 rounded-lg text-xs font-semibold">
            <span>Portfolio Claim Rate: {stats.claimRate}%</span>
          </div>
        )}

        {/* Best Model Badge */}
        {modelTrained && (
          <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-lg text-xs font-medium">
            <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
            <span className="font-semibold">Top Model: {bestModelName}</span>
          </div>
        )}

        {/* Download PDF Report Button */}
        <button
          id="btn-download-pdf-report"
          onClick={onDownloadReport}
          disabled={!modelTrained || isGeneratingReport}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs sm:text-sm font-semibold text-white transition-all shadow-xs ${
            !modelTrained || isGeneratingReport
              ? 'bg-slate-300 cursor-not-allowed'
              : 'bg-cyan-700 hover:bg-cyan-800 active:bg-cyan-900 hover:shadow-sm'
          }`}
        >
          {isGeneratingReport ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin text-white" />
              <span className="hidden xs:inline">Generating PDF...</span>
            </>
          ) : (
            <>
              <FileDown className="w-4 h-4 text-white" />
              <span className="hidden xs:inline">Download Report</span>
            </>
          )}
        </button>
      </div>
    </header>
  );
};
