import React, { useMemo } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  Cell,
} from 'recharts';

interface ProbabilityDistributionChartProps {
  probabilities: number[];
  modelName: string;
}

export const ProbabilityDistributionChart: React.FC<ProbabilityDistributionChartProps> = ({
  probabilities,
  modelName,
}) => {
  const data = useMemo(() => {
    // Bucket probabilities into 10 bins: 0-10%, 10-20%, ..., 90-100%
    const bins = [
      { bin: '0–10%', min: 0.0, max: 0.1, count: 0, category: 'low' },
      { bin: '10–20%', min: 0.1, max: 0.2, count: 0, category: 'low' },
      { bin: '20–30%', min: 0.2, max: 0.3, count: 0, category: 'low' },
      { bin: '30–40%', min: 0.3, max: 0.4, count: 0, category: 'medium' },
      { bin: '40–50%', min: 0.4, max: 0.5, count: 0, category: 'medium' },
      { bin: '50–60%', min: 0.5, max: 0.6, count: 0, category: 'medium' },
      { bin: '60–70%', min: 0.6, max: 0.7, count: 0, category: 'high' },
      { bin: '70–80%', min: 0.7, max: 0.8, count: 0, category: 'high' },
      { bin: '80–90%', min: 0.8, max: 0.9, count: 0, category: 'high' },
      { bin: '90–100%', min: 0.9, max: 1.01, count: 0, category: 'high' },
    ];

    for (const p of probabilities) {
      for (const b of bins) {
        if (p >= b.min && p < b.max) {
          b.count++;
          break;
        }
      }
    }

    return bins;
  }, [probabilities]);

  const lowCount = data.filter((d) => d.category === 'low').reduce((s, d) => s + d.count, 0);
  const medCount = data.filter((d) => d.category === 'medium').reduce((s, d) => s + d.count, 0);
  const highCount = data.filter((d) => d.category === 'high').reduce((s, d) => s + d.count, 0);
  const total = probabilities.length || 1;

  const getColor = (category: string) => {
    if (category === 'low') return '#10b981'; // emerald
    if (category === 'medium') return '#f59e0b'; // amber
    return '#ef4444'; // rose
  };

  return (
    <div id="x2m7v4" className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 pb-2 border-b border-slate-100">
        <div>
          <h3 className="text-sm font-semibold text-slate-900">
            Predicted Claim Probability Distribution ({modelName})
          </h3>
          <p className="text-xs text-slate-500">
            Histogram of continuous model probabilities evaluated across {probabilities.length} test records
          </p>
        </div>
      </div>

      {/* Probability tier summary chips */}
      <div className="grid grid-cols-3 gap-2.5 text-xs">
        <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-lg">
          <div className="text-[11px] font-semibold text-emerald-800">Low Probability (&lt;30%)</div>
          <div className="text-base font-bold text-emerald-950 mt-0.5">
            {lowCount} ({Math.round((lowCount / total) * 100)}%)
          </div>
        </div>

        <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-lg">
          <div className="text-[11px] font-semibold text-amber-800">Medium (30%–60%)</div>
          <div className="text-base font-bold text-amber-950 mt-0.5">
            {medCount} ({Math.round((medCount / total) * 100)}%)
          </div>
        </div>

        <div className="p-2.5 bg-rose-50 border border-rose-200 rounded-lg">
          <div className="text-[11px] font-semibold text-rose-800">High Risk (&gt;60%)</div>
          <div className="text-base font-bold text-rose-950 mt-0.5">
            {highCount} ({Math.round((highCount / total) * 100)}%)
          </div>
        </div>
      </div>

      <div className="h-64 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 10, right: 10, left: -10, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
            <XAxis
              dataKey="bin"
              tick={{ fontSize: 10, fill: '#64748b' }}
              interval={0}
              angle={-20}
              textAnchor="end"
              height={36}
            />
            <YAxis tick={{ fontSize: 11, fill: '#64748b' }} allowDecimals={false} />
            <Tooltip
              formatter={(val: any) => [`${val} test records`, 'Frequency']}
              contentStyle={{
                backgroundColor: '#ffffff',
                borderColor: '#e2e8f0',
                borderRadius: '0.5rem',
                fontSize: '12px',
              }}
            />
            <Bar dataKey="count" radius={[4, 4, 0, 0]}>
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={getColor(entry.category)} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};
