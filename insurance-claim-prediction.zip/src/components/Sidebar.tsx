import React from 'react';
import {
  LayoutDashboard,
  BrainCircuit,
  BarChart3,
  GitCompare,
  FileSpreadsheet,
  CheckCircle2,
  ChevronRight,
  ShieldAlert,
} from 'lucide-react';

export type PageId = 'dashboard' | 'predictor' | 'analysis' | 'performance';

interface SidebarProps {
  activePage: PageId;
  onSelectPage: (page: PageId) => void;
  isOpen: boolean;
  onCloseMobile: () => void;
  datasetLoaded: boolean;
  totalPolicies: number;
  bestModelName: string;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activePage,
  onSelectPage,
  isOpen,
  onCloseMobile,
  datasetLoaded,
  totalPolicies,
  bestModelName,
}) => {
  const navItems: { id: PageId; label: string; icon: React.ComponentType<{ className?: string }>; badge?: string }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'predictor', label: 'Claim Predictor', icon: BrainCircuit, badge: 'Live ML' },
    { id: 'analysis', label: 'Insurance Analysis', icon: BarChart3 },
    { id: 'performance', label: 'Model Performance', icon: GitCompare, badge: 'Eval' },
  ];

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          id="sidebar-mobile-backdrop"
          className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-40 lg:hidden transition-opacity"
          onClick={onCloseMobile}
        />
      )}

      {/* Sidebar Container */}
      <aside
        id="app-sidebar"
        className={`fixed top-0 bottom-0 left-0 z-50 w-72 bg-white border-r border-slate-200 flex flex-col transition-transform duration-200 ease-in-out lg:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Brand Header */}
        <div className="p-6 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-700 flex items-center justify-center text-white shadow-xs">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <div className="font-semibold text-slate-900 text-sm tracking-tight leading-tight">
                InsureAI Analytics
              </div>
              <div className="text-xs text-slate-500 font-medium">Claim Likelihood Engine</div>
            </div>
          </div>
        </div>

        {/* Navigation links */}
        <div className="flex-1 px-4 py-6 space-y-1.5 overflow-y-auto">
          <div className="px-3 pb-2 text-[11px] font-semibold tracking-wider text-slate-400 uppercase">
            Platform Modules
          </div>

          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activePage === item.id;
            return (
              <button
                key={item.id}
                id={`nav-item-${item.id}`}
                onClick={() => {
                  onSelectPage(item.id);
                  onCloseMobile();
                }}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                  isActive
                    ? 'bg-cyan-50 text-cyan-900 font-semibold'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon
                    className={`w-4 h-4 ${
                      isActive ? 'text-cyan-700' : 'text-slate-400 group-hover:text-slate-600'
                    }`}
                  />
                  <span>{item.label}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  {item.badge && (
                    <span
                      className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium ${
                        isActive ? 'bg-cyan-200/60 text-cyan-950' : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                  {isActive && <ChevronRight className="w-4 h-4 text-cyan-700" />}
                </div>
              </button>
            );
          })}
        </div>

        {/* Runtime System Status Footer */}
        <div className="p-4 m-4 bg-slate-50 rounded-xl border border-slate-200/80 space-y-2.5">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-500 font-medium flex items-center gap-1.5">
              <FileSpreadsheet className="w-3.5 h-3.5 text-slate-400" />
              Dataset Status
            </span>
            <span
              className={`inline-flex items-center gap-1 font-semibold text-[11px] ${
                datasetLoaded ? 'text-emerald-700' : 'text-amber-700'
              }`}
            >
              <CheckCircle2 className="w-3 h-3" />
              {datasetLoaded ? `${totalPolicies} Records` : 'Loading...'}
            </span>
          </div>

          <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-200/60">
            <span className="text-slate-500 font-medium">Champion Model</span>
            <span className="font-semibold text-slate-800 text-[11px] truncate max-w-[110px]">
              {bestModelName || 'Training...'}
            </span>
          </div>
          <div className="text-[10px] text-slate-400 font-normal leading-relaxed">
            Pure in-browser client ML execution (Logistic Regression & Random Forest).
          </div>
        </div>
      </aside>
    </>
  );
};
