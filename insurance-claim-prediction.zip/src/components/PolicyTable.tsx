import React, { useState, useMemo } from 'react';
import { CleanedPolicyRecord, DatasetStats } from '../types';
import { Search, Filter, ArrowUpDown, ChevronLeft, ChevronRight, Eye } from 'lucide-react';
import { PolicyDetailModal } from './PolicyDetailModal';

interface PolicyTableProps {
  records: CleanedPolicyRecord[];
  stats: DatasetStats;
  uniquePolicyTypes: string[];
  uniqueVehicleTypes: string[];
  uniqueGenders: string[];
}

export const PolicyTable: React.FC<PolicyTableProps> = ({
  records,
  stats,
  uniquePolicyTypes,
  uniqueVehicleTypes,
  uniqueGenders,
}) => {
  const [search, setSearch] = useState('');
  const [selectedPolicyType, setSelectedPolicyType] = useState('ALL');
  const [selectedVehicleType, setSelectedVehicleType] = useState('ALL');
  const [selectedGender, setSelectedGender] = useState('ALL');
  const [selectedClaimStatus, setSelectedClaimStatus] = useState<'ALL' | '1' | '0'>('ALL');
  const [sortField, setSortField] = useState<keyof CleanedPolicyRecord>('policy_id');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [selectedPolicyForModal, setSelectedPolicyForModal] = useState<CleanedPolicyRecord | null>(null);

  // Filtering
  const filtered = useMemo(() => {
    return records.filter((r) => {
      if (search) {
        const query = search.toLowerCase();
        const matchesId = r.policy_id.toLowerCase().includes(query);
        const matchesPolicyType = r.policy_type.toLowerCase().includes(query);
        const matchesVehicleType = r.vehicle_type.toLowerCase().includes(query);
        if (!matchesId && !matchesPolicyType && !matchesVehicleType) return false;
      }

      if (selectedPolicyType !== 'ALL' && r.policy_type !== selectedPolicyType) return false;
      if (selectedVehicleType !== 'ALL' && r.vehicle_type !== selectedVehicleType) return false;
      if (selectedGender !== 'ALL' && r.gender !== selectedGender) return false;
      if (selectedClaimStatus !== 'ALL') {
        const target = selectedClaimStatus === '1' ? 1 : 0;
        if (r.claim !== target) return false;
      }

      return true;
    });
  }, [records, search, selectedPolicyType, selectedVehicleType, selectedGender, selectedClaimStatus]);

  // Sorting
  const sorted = useMemo(() => {
    return [...filtered].sort((a, b) => {
      let aVal = (a as any)[sortField];
      let bVal = (b as any)[sortField];

      if (typeof aVal === 'string') {
        return sortOrder === 'asc'
          ? aVal.localeCompare(bVal)
          : bVal.localeCompare(aVal);
      }
      return sortOrder === 'asc' ? aVal - bVal : bVal - aVal;
    });
  }, [filtered, sortField, sortOrder]);

  // Pagination
  const totalPages = Math.max(1, Math.ceil(sorted.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const paginated = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return sorted.slice(start, start + pageSize);
  }, [sorted, currentPage, pageSize]);

  const handleSort = (field: keyof CleanedPolicyRecord) => {
    if (sortField === field) {
      setSortOrder((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortField(field);
      setSortOrder('asc');
    }
  };

  return (
    <div id="policy-explorer" className="bg-white rounded-xl border border-slate-200 shadow-xs flex flex-col min-w-0">
      {/* Table Filter & Search Controls */}
      <div className="p-4 sm:p-5 border-b border-slate-200 space-y-3">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          {/* Search bar */}
          <div className="relative flex-1 min-w-[240px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              id="input-policy-search"
              type="text"
              placeholder="Search by Policy ID, Policy Type, or Vehicle..."
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setPage(1);
              }}
              className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 outline-none"
            />
          </div>

          <div className="flex items-center gap-2 self-end sm:self-auto text-xs text-slate-500 font-medium">
            <span>
              Showing <strong className="text-slate-900">{filtered.length}</strong> of {records.length} records
            </span>
          </div>
        </div>

        {/* Filters bar */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
          <span className="text-slate-400 font-medium flex items-center gap-1 shrink-0">
            <Filter className="w-3.5 h-3.5" />
            Filters:
          </span>

          {/* Policy Type filter */}
          <select
            id="filter-policy-type"
            value={selectedPolicyType}
            onChange={(e) => {
              setSelectedPolicyType(e.target.value);
              setPage(1);
            }}
            className="px-2.5 py-1.5 border border-slate-200 rounded-lg bg-slate-50 text-slate-700 outline-none shrink-0"
          >
            <option value="ALL">Policy Type: All</option>
            {uniquePolicyTypes.map((pt) => (
              <option key={pt} value={pt}>
                {pt}
              </option>
            ))}
          </select>

          {/* Vehicle Type filter */}
          <select
            id="filter-vehicle-type"
            value={selectedVehicleType}
            onChange={(e) => {
              setSelectedVehicleType(e.target.value);
              setPage(1);
            }}
            className="px-2.5 py-1.5 border border-slate-200 rounded-lg bg-slate-50 text-slate-700 outline-none shrink-0"
          >
            <option value="ALL">Vehicle: All</option>
            {uniqueVehicleTypes.map((vt) => (
              <option key={vt} value={vt}>
                {vt}
              </option>
            ))}
          </select>

          {/* Gender filter */}
          <select
            id="filter-gender"
            value={selectedGender}
            onChange={(e) => {
              setSelectedGender(e.target.value);
              setPage(1);
            }}
            className="px-2.5 py-1.5 border border-slate-200 rounded-lg bg-slate-50 text-slate-700 outline-none shrink-0"
          >
            <option value="ALL">Gender: All</option>
            {uniqueGenders.map((g) => (
              <option key={g} value={g}>
                {g}
              </option>
            ))}
          </select>

          {/* Claim Status filter */}
          <select
            id="filter-claim-status"
            value={selectedClaimStatus}
            onChange={(e) => {
              setSelectedClaimStatus(e.target.value as any);
              setPage(1);
            }}
            className="px-2.5 py-1.5 border border-slate-200 rounded-lg bg-slate-50 text-slate-700 outline-none shrink-0"
          >
            <option value="ALL">Claim Status: All</option>
            <option value="1">Claim Filed (1)</option>
            <option value="0">No Claim (0)</option>
          </select>

          {(search || selectedPolicyType !== 'ALL' || selectedVehicleType !== 'ALL' || selectedGender !== 'ALL' || selectedClaimStatus !== 'ALL') && (
            <button
              onClick={() => {
                setSearch('');
                setSelectedPolicyType('ALL');
                setSelectedVehicleType('ALL');
                setSelectedGender('ALL');
                setSelectedClaimStatus('ALL');
                setPage(1);
              }}
              className="text-xs text-cyan-700 hover:text-cyan-900 font-semibold px-2 py-1 shrink-0"
            >
              Reset Filters
            </button>
          )}
        </div>
      </div>

      {/* Table with horizontal scroll contained inside */}
      <div className="overflow-x-auto min-w-0">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider">
              <th
                className="py-3 px-3.5 cursor-pointer hover:text-slate-900"
                onClick={() => handleSort('policy_id')}
              >
                <div className="flex items-center gap-1">
                  Policy ID
                  <ArrowUpDown className="w-3 h-3" />
                </div>
              </th>
              <th
                className="py-3 px-3 cursor-pointer hover:text-slate-900"
                onClick={() => handleSort('customer_age')}
              >
                <div className="flex items-center gap-1">
                  Age / Gender
                  <ArrowUpDown className="w-3 h-3" />
                </div>
              </th>
              <th className="py-3 px-3">Policy Type</th>
              <th className="py-3 px-3">Vehicle</th>
              <th
                className="py-3 px-3 cursor-pointer hover:text-slate-900"
                onClick={() => handleSort('premium_amount')}
              >
                <div className="flex items-center gap-1">
                  Premium
                  <ArrowUpDown className="w-3 h-3" />
                </div>
              </th>
              <th className="py-3 px-3">Coverage</th>
              <th className="py-3 px-3 text-center">Prev Claims</th>
              <th className="py-3 px-3 text-center">Accident</th>
              <th
                className="py-3 px-3 cursor-pointer hover:text-slate-900 text-center"
                onClick={() => handleSort('claim')}
              >
                <div className="flex items-center justify-center gap-1">
                  Claim Status
                  <ArrowUpDown className="w-3 h-3" />
                </div>
              </th>
              <th className="py-3 px-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {paginated.length === 0 ? (
              <tr>
                <td colSpan={10} className="py-8 text-center text-slate-500">
                  No policy records match your filter criteria.
                </td>
              </tr>
            ) : (
              paginated.map((r) => {
                const isClaim = r.claim === 1;
                return (
                  <tr
                    key={r.policy_id}
                    className="hover:bg-slate-50/80 transition-colors cursor-pointer group"
                    onClick={() => setSelectedPolicyForModal(r)}
                  >
                    <td className="py-3 px-3.5 font-semibold text-slate-900 whitespace-nowrap">
                      {r.policy_id}
                    </td>
                    <td className="py-3 px-3 text-slate-700 whitespace-nowrap">
                      {r.customer_age} yrs • <span className="text-slate-500">{r.gender}</span>
                    </td>
                    <td className="py-3 px-3 text-slate-700 whitespace-nowrap">
                      <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 text-[11px] font-medium">
                        {r.policy_type}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-slate-700 whitespace-nowrap">
                      {r.vehicle_type} ({r.vehicle_age} yrs)
                    </td>
                    <td className="py-3 px-3 font-medium text-slate-900 whitespace-nowrap">
                      ${r.premium_amount.toLocaleString()}
                    </td>
                    <td className="py-3 px-3 text-slate-600 whitespace-nowrap">
                      ${r.coverage_amount.toLocaleString()}
                    </td>
                    <td className="py-3 px-3 text-center text-slate-700 whitespace-nowrap">
                      <span
                        className={`font-semibold ${
                          r.previous_claims > 0 ? 'text-amber-700' : 'text-slate-500'
                        }`}
                      >
                        {r.previous_claims}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-center text-slate-700 whitespace-nowrap">
                      <span
                        className={`px-1.5 py-0.5 rounded text-[10px] font-semibold ${
                          r.accident_history === 'Yes'
                            ? 'bg-rose-50 text-rose-700'
                            : 'bg-emerald-50 text-emerald-700'
                        }`}
                      >
                        {r.accident_history}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-center whitespace-nowrap">
                      <span
                        className={`inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold ${
                          isClaim
                            ? 'bg-rose-100 text-rose-800 border border-rose-200'
                            : 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                        }`}
                      >
                        {isClaim ? 'Claim (1)' : 'No Claim (0)'}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right whitespace-nowrap">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedPolicyForModal(r);
                        }}
                        className="p-1.5 text-slate-400 hover:text-cyan-700 hover:bg-cyan-50 rounded-md transition-colors"
                        title="View details"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Footer */}
      <div className="p-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-600">
        <div className="flex items-center gap-2">
          <span>Rows per page:</span>
          <select
            value={pageSize}
            onChange={(e) => {
              setPageSize(Number(e.target.value));
              setPage(1);
            }}
            className="px-2 py-1 border border-slate-200 rounded-md bg-white text-slate-700 outline-none"
          >
            <option value={10}>10</option>
            <option value={25}>25</option>
            <option value={50}>50</option>
          </select>
          <span className="text-slate-400">|</span>
          <span>
            Page {currentPage} of {totalPages}
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={currentPage === 1}
            className="p-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <span className="px-2 font-medium">
            {currentPage} / {totalPages}
          </span>
          <button
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            disabled={currentPage === totalPages}
            className="p-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Details modal */}
      {selectedPolicyForModal && (
        <PolicyDetailModal
          policy={selectedPolicyForModal}
          onClose={() => setSelectedPolicyForModal(null)}
          stats={stats}
        />
      )}
    </div>
  );
};
