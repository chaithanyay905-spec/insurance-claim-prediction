import React from 'react';
import { CleanedPolicyRecord, DatasetStats } from '../types';
import { X, Shield, User, Car, AlertCircle, CheckCircle2 } from 'lucide-react';

interface PolicyDetailModalProps {
  policy: CleanedPolicyRecord | null;
  onClose: () => void;
  stats: DatasetStats;
}

export const PolicyDetailModal: React.FC<PolicyDetailModalProps> = ({ policy, onClose, stats }) => {
  if (!policy) return null;

  const isClaim = policy.claim === 1;

  const compare = (val: number, avg: number, unit = '') => {
    const diff = val - avg;
    const isHigher = diff > 0;
    return (
      <span
        className={`text-[11px] font-medium ml-1.5 ${
          isHigher ? 'text-amber-700' : 'text-slate-500'
        }`}
      >
        ({isHigher ? '+' : ''}
        {typeof val === 'number' && Number.isInteger(val) ? diff : diff.toFixed(1)} {unit} vs avg)
      </span>
    );
  };

  return (
    <div
      id="policy-detail-modal-backdrop"
      className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
      onClick={onClose}
    >
      <div
        id="policy-detail-modal-content"
        className="bg-white rounded-2xl max-w-2xl w-full border border-slate-200 shadow-xl overflow-hidden my-8"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-700 flex items-center justify-center text-white">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-slate-900">{policy.policy_id}</h3>
                <span
                  className={`px-2 py-0.5 rounded-full text-xs font-semibold ${
                    isClaim
                      ? 'bg-rose-100 text-rose-800 border border-rose-200'
                      : 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                  }`}
                >
                  {isClaim ? 'Claim Filed (Class 1)' : 'No Claim (Class 0)'}
                </span>
              </div>
              <p className="text-xs text-slate-500">Historical Policy Profile & Risk Summary</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content sections */}
        <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          {/* Customer profile */}
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-700 uppercase tracking-wider">
              <User className="w-4 h-4 text-cyan-600" />
              Customer Information
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/80">
                <div className="text-[11px] text-slate-500">Customer Age</div>
                <div className="text-sm font-semibold text-slate-900 mt-0.5">
                  {policy.customer_age} yrs
                  {compare(policy.customer_age, stats.avgCustomerAge, 'yrs')}
                </div>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/80">
                <div className="text-[11px] text-slate-500">Gender</div>
                <div className="text-sm font-semibold text-slate-900 mt-0.5">{policy.gender}</div>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/80">
                <div className="text-[11px] text-slate-500">Annual Income</div>
                <div className="text-sm font-semibold text-slate-900 mt-0.5">
                  ${policy.annual_income.toLocaleString()}
                </div>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/80">
                <div className="text-[11px] text-slate-500">Driving Experience</div>
                <div className="text-sm font-semibold text-slate-900 mt-0.5">
                  {policy.driving_experience} yrs
                  {compare(policy.driving_experience, stats.avgDrivingExperience, 'yrs')}
                </div>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/80">
                <div className="text-[11px] text-slate-500">Age Cohort</div>
                <div className="text-sm font-semibold text-slate-900 mt-0.5">{policy.age_group}</div>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/80">
                <div className="text-[11px] text-slate-500">Experience Tier</div>
                <div className="text-sm font-semibold text-slate-900 mt-0.5">
                  {policy.experience_group}
                </div>
              </div>
            </div>
          </div>

          {/* Policy & Financials */}
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-700 uppercase tracking-wider">
              <Shield className="w-4 h-4 text-cyan-600" />
              Policy & Coverage Details
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/80">
                <div className="text-[11px] text-slate-500">Policy Type</div>
                <div className="text-sm font-semibold text-slate-900 mt-0.5">
                  {policy.policy_type}
                </div>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/80">
                <div className="text-[11px] text-slate-500">Policy Tenure</div>
                <div className="text-sm font-semibold text-slate-900 mt-0.5">
                  {policy.policy_tenure} yrs
                  {compare(policy.policy_tenure, stats.avgPolicyTenure, 'yrs')}
                </div>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/80">
                <div className="text-[11px] text-slate-500">Annual Premium</div>
                <div className="text-sm font-semibold text-slate-900 mt-0.5">
                  ${policy.premium_amount.toLocaleString()}
                  {compare(policy.premium_amount, stats.avgPremium, '$')}
                </div>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/80">
                <div className="text-[11px] text-slate-500">Coverage Limit</div>
                <div className="text-sm font-semibold text-slate-900 mt-0.5">
                  ${policy.coverage_amount.toLocaleString()}
                </div>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/80">
                <div className="text-[11px] text-slate-500">Prem / Coverage Ratio</div>
                <div className="text-sm font-semibold text-slate-900 mt-0.5">
                  {(policy.premium_to_coverage_ratio * 100).toFixed(2)}%
                </div>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/80">
                <div className="text-[11px] text-slate-500">Tenure Classification</div>
                <div className="text-sm font-semibold text-slate-900 mt-0.5">
                  {policy.policy_tenure >= 5 ? 'Loyal (>5 yrs)' : 'Standard'}
                </div>
              </div>
            </div>
          </div>

          {/* Vehicle & History */}
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-700 uppercase tracking-wider">
              <Car className="w-4 h-4 text-cyan-600" />
              Vehicle & Claim Background
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/80">
                <div className="text-[11px] text-slate-500">Vehicle Type</div>
                <div className="text-sm font-semibold text-slate-900 mt-0.5">
                  {policy.vehicle_type}
                </div>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/80">
                <div className="text-[11px] text-slate-500">Vehicle Age</div>
                <div className="text-sm font-semibold text-slate-900 mt-0.5">
                  {policy.vehicle_age} yrs
                </div>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/80">
                <div className="text-[11px] text-slate-500">Vehicle Usage</div>
                <div className="text-sm font-semibold text-slate-900 mt-0.5">
                  {policy.vehicle_usage}
                </div>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/80">
                <div className="text-[11px] text-slate-500">Previous Claims</div>
                <div className="text-sm font-semibold text-slate-900 mt-0.5">
                  {policy.previous_claims} claims
                </div>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/80">
                <div className="text-[11px] text-slate-500">Accident History</div>
                <div className="text-sm font-semibold text-slate-900 mt-0.5">
                  {policy.accident_history}
                </div>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/80">
                <div className="text-[11px] text-slate-500">Claim History</div>
                <div className="text-sm font-semibold text-slate-900 mt-0.5">
                  {policy.claim_history}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-lg text-xs font-semibold transition-colors"
          >
            Close Details
          </button>
        </div>
      </div>
    </div>
  );
};
