import React from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
} from 'recharts';
import { FeatureImportanceItem } from '../types';

interface FeatureImportanceChartProps {
  importance: FeatureImportanceItem[];
  modelName: string;
}

export const FeatureImportanceChart: React.FC<FeatureImportanceChartProps> = ({
  importance,
  modelName,
}) => {
  const topFeatures = [...importance].slice(0, 10).reverse().map((item) => ({
    name: item.feature.replace(/_/g, ' '),
    importance: Math.round(item.importance * 1000) / 10,
    rawName: item.feature,
  }));

  return (
    <div id="m5x8q2" className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-3">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 pb-2 border-b border-slate-100">
        <div>
          <h3 className="text-sm font-semibold text-slate-900">
            Model Feature Importance ({modelName})
          </h3>
          <p className="text-xs text-slate-500">
            Ranked by normalized mean Gini impurity reduction across decision trees
          </p>
        </div>
        <span className="text-[11px] text-slate-400 font-medium">Top 10 Influential Features</span>
      </div>

      <div className="h-72 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            data={topFeatures}
            layout="vertical"
            margin={{ top: 5, right: 30, left: 90, bottom: 5 }}
          >
            <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
            <XAxis
              type="number"
              domain={[0, 100]}
              tickFormatter={(v) => `${v}%`}
              tick={{ fontSize: 11, fill: '#64748b' }}
            />
            <YAxis
              type="category"
              dataKey="name"
              tick={{ fontSize: 11, fill: '#334155' }}
              width={85}
            />
            <Tooltip
              formatter={(val: any) => [`${val}%`, 'Relative Importance']}
              contentStyle={{
                backgroundColor: '#ffffff',
                borderColor: '#e2e8f0',
                borderRadius: '0.5rem',
                fontSize: '12px',
                boxShadow: '0 1px 3px 0 rgb(0 0 0 / 0.1)',
              }}
            />
            <Bar
              dataKey="importance"
              fill="#0e7490"
              radius={[0, 4, 4, 0]}
              animationDuration={800}
            />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="text-[11px] text-slate-400">
        * Higher values represent features that provided greater classification purity gain during tree node splits.
      </div>
    </div>
  );
};
