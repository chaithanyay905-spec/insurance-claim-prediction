import React from 'react';
import {
  FileText,
  AlertTriangle,
  ShieldCheck,
  Percent,
  DollarSign,
  User,
  Clock,
  Sparkles,
  ArrowRight,
  TrendingUp,
} from 'lucide-react';
import { CleanedPolicyRecord, DatasetStats } from '../types';
import { TrainingContext } from '../ml/modelTraining';
import { StatCard } from '../components/StatCard';
import {
  analyzeByPolicyType,
  analyzeByAgeGroup,
  analyzeByVehicleType,
  analyzeByPremiumRange,
  analyzeByPreviousClaims,
  analyzeByAccidentHistory,
} from '../utils/insuranceAnalysis';
import { generateDynamicInsights } from '../utils/insights';
import {
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  Legend,
} from 'recharts';

interface DashboardProps {
  records: CleanedPolicyRecord[];
  stats: DatasetStats;
  trainingContext: TrainingContext | null;
  onNavigateToPredictor: () => void;
  onNavigateToAnalysis: () => void;
  onNavigateToPerformance: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  records,
  stats,
  trainingContext,
  onNavigateToPredictor,
  onNavigateToAnalysis,
  onNavigateToPerformance,
}) => {
  const policyTypeData = analyzeByPolicyType(records);
  const ageGroupData = analyzeByAgeGroup(records);
  const vehicleTypeData = analyzeByVehicleType(records);
  const premiumRangeData = analyzeByPremiumRange(records);
  const prevClaimsData = analyzeByPreviousClaims(records);
  const accidentData = analyzeByAccidentHistory(records);

  const distributionData = [
    { name: 'No Claim (0)', value: stats.totalNoClaims, color: '#10b981' },
    { name: 'Claim Filed (1)', value: stats.totalClaims, color: '#ef4444' },
  ];

  const insights = trainingContext
    ? generateDynamicInsights(stats, trainingContext).slice(0, 3)
    : [];

  return (
    <div id="dashboard-page" className="space-y-6 pb-12">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-cyan-950 text-white rounded-2xl p-6 sm:p-8 shadow-sm relative overflow-hidden">
        <div className="relative z-10 max-w-2xl space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/20 text-cyan-200 text-xs font-semibold backdrop-blur-xs border border-cyan-400/30">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            Machine Learning In-Browser Suite
          </div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
            Insurance Claim Risk Analytics & Prediction
          </h2>
          <p className="text-slate-300 text-xs sm:text-sm leading-relaxed">
            Real-time statistical evaluation comparing Logistic Regression and Random Forest classifiers on {stats.totalPolicies.toLocaleString()} historical insurance policies.
          </p>

          <div className="pt-3 flex flex-wrap gap-3">
            <button
              onClick={onNavigateToPredictor}
              className="inline-flex items-center gap-2 px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white text-xs sm:text-sm font-semibold rounded-lg transition-colors shadow-xs"
            >
              Test Claim Predictor
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={onNavigateToPerformance}
              className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 text-white text-xs sm:text-sm font-medium rounded-lg backdrop-blur-xs transition-colors border border-white/10"
            >
              View Model Benchmarks
            </button>
          </div>
        </div>
      </div>

      {/* 8 Statistic Cards (Section 5) */}
      <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          id="stat-total-policies"
          title="Total Policies"
          value={stats.totalPolicies.toLocaleString()}
          subtitle="Validated records"
          icon={FileText}
        />
        <StatCard
          id="stat-total-claims"
          title="Total Claims"
          value={stats.totalClaims.toLocaleString()}
          subtitle="Observed claims"
          icon={AlertTriangle}
          badge={`${stats.claimRate}% rate`}
          badgeVariant="warning"
        />
        <StatCard
          id="stat-no-claim-policies"
          title="No-Claim Policies"
          value={stats.totalNoClaims.toLocaleString()}
          subtitle="Safe policyholders"
          icon={ShieldCheck}
          badge={`${stats.noClaimRate}% safe`}
          badgeVariant="success"
        />
        <StatCard
          id="stat-best-model"
          title="Best Performing Model"
          value={trainingContext?.bestModelName || 'Training...'}
          subtitle={
            trainingContext
              ? `F1: ${(
                  (trainingContext.bestModelName === 'Random Forest'
                    ? trainingContext.randomForest.metrics.f1
                    : trainingContext.logisticRegression.metrics.f1) * 100
                ).toFixed(1)}%`
              : 'Evaluating...'
          }
          icon={Sparkles}
          badge="Evaluated"
          badgeVariant="accent"
        />
        <StatCard
          id="stat-avg-premium"
          title="Average Premium"
          value={`$${stats.avgPremium.toLocaleString()}`}
          subtitle="Annual premium"
          icon={DollarSign}
        />
        <StatCard
          id="stat-avg-age"
          title="Average Customer Age"
          value={`${stats.avgCustomerAge} yrs`}
          subtitle="Across all segments"
          icon={User}
        />
        <StatCard
          id="stat-avg-tenure"
          title="Average Policy Tenure"
          value={`${stats.avgPolicyTenure} yrs`}
          subtitle="Retention longevity"
          icon={Clock}
        />
        <StatCard
          id="stat-claim-rate"
          title="Overall Claim Rate"
          value={`${stats.claimRate}%`}
          subtitle="Target class ratio"
          icon={Percent}
        />
      </div>

      {/* Row 1 Charts: Claim vs No-Claim Distribution & Claims by Policy Type */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chart 1: Claim vs No-Claim Distribution */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div className="pb-2 border-b border-slate-100">
            <h3 className="text-sm font-semibold text-slate-900">
              Claim vs No-Claim Distribution
            </h3>
            <p className="text-xs text-slate-500">Historical target variable breakdown</p>
          </div>

          <div className="h-64 w-full my-2">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={distributionData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={85}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {distributionData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(val: any, name: any) => [
                    `${val} policies (${Math.round((val / (stats.totalPolicies || 1)) * 100)}%)`,
                    name,
                  ]}
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    borderColor: '#e2e8f0',
                    borderRadius: '0.5rem',
                    fontSize: '12px',
                  }}
                />
                <Legend
                  verticalAlign="bottom"
                  height={36}
                  formatter={(value) => <span className="text-xs text-slate-600">{value}</span>}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="flex items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-100">
            <span>No Claim: {stats.noClaimRate}%</span>
            <span className="font-semibold text-rose-700">Claim Rate: {stats.claimRate}%</span>
          </div>
        </div>

        {/* Chart 2: Claims by Policy Type */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs lg:col-span-2 flex flex-col justify-between">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-semibold text-slate-900">Claims by Policy Type</h3>
              <p className="text-xs text-slate-500">Policy distribution vs claim frequency</p>
            </div>
            <button
              onClick={onNavigateToAnalysis}
              className="text-xs text-cyan-700 hover:text-cyan-800 font-semibold"
            >
              Explore Analysis &rarr;
            </button>
          </div>

          <div className="h-64 w-full my-2">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={policyTypeData} margin={{ top: 10, right: 10, left: -10, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#64748b' }} />
                <YAxis tick={{ fontSize: 11, fill: '#64748b' }} />
                <Tooltip
                  formatter={(val: any, name: any) => [val, name === 'claims' ? 'Claims Filed' : 'No Claims']}
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    borderColor: '#e2e8f0',
                    borderRadius: '0.5rem',
                    fontSize: '12px',
                  }}
                />
                <Legend
                  verticalAlign="bottom"
                  formatter={(value) => (
                    <span className="text-xs text-slate-600">
                      {value === 'claims' ? 'Claims Filed' : 'No Claims'}
                    </span>
                  )}
                />
                <Bar dataKey="noClaims" fill="#cbd5e1" radius={[4, 4, 0, 0]} name="noClaims" />
                <Bar dataKey="claims" fill="#0e7490" radius={[4, 4, 0, 0]} name="claims" />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="text-[11px] text-slate-400">
            * Compares observed claim occurrences across coverage tiers.
          </div>
        </div>
      </div>

      {/* Row 2 Charts: Claims by Age Group & Vehicle Type */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart 3: Claims by Age Group */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-2">
          <div className="pb-2 border-b border-slate-100">
            <h3 className="text-sm font-semibold text-slate-900">Claim Rate by Age Cohort</h3>
            <p className="text-xs text-slate-500">Claim frequency percentage across age groups</p>
          </div>

          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={ageGroupData} margin={{ top: 10, right: 10, left: -15, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" tick={{ fontSize: 10, fill: '#64748b' }} />
                <YAxis
                  tick={{ fontSize: 11, fill: '#64748b' }}
                  tickFormatter={(v) => `${v}%`}
                  domain={[0, 'auto']}
                />
                <Tooltip
                  formatter={(val: any) => [`${val}%`, 'Observed Claim Rate']}
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    borderColor: '#e2e8f0',
                    borderRadius: '0.5rem',
                    fontSize: '12px',
                  }}
                />
                <Bar dataKey="claimRate" fill="#0e7490" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 4: Claims by Vehicle Type */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-2">
          <div className="pb-2 border-b border-slate-100">
            <h3 className="text-sm font-semibold text-slate-900">Claim Rate by Vehicle Type</h3>
            <p className="text-xs text-slate-500">Observed claim rate across vehicle categories</p>
          </div>

          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={vehicleTypeData} margin={{ top: 10, right: 10, left: -15, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" tick={{ fontSize: 10, fill: '#64748b' }} />
                <YAxis
                  tick={{ fontSize: 11, fill: '#64748b' }}
                  tickFormatter={(v) => `${v}%`}
                  domain={[0, 'auto']}
                />
                <Tooltip
                  formatter={(val: any) => [`${val}%`, 'Observed Claim Rate']}
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    borderColor: '#e2e8f0',
                    borderRadius: '0.5rem',
                    fontSize: '12px',
                  }}
                />
                <Bar dataKey="claimRate" fill="#3b82f6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Row 3 Charts: Claims by Premium Range & Historical Claims */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart 5: Claims by Premium Range */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-2">
          <div className="pb-2 border-b border-slate-100">
            <h3 className="text-sm font-semibold text-slate-900">Claims by Premium Range</h3>
            <p className="text-xs text-slate-500">Observed claim rate across premium brackets</p>
          </div>

          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={premiumRangeData} margin={{ top: 10, right: 10, left: -15, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" tick={{ fontSize: 10, fill: '#64748b' }} />
                <YAxis
                  tick={{ fontSize: 11, fill: '#64748b' }}
                  tickFormatter={(v) => `${v}%`}
                  domain={[0, 'auto']}
                />
                <Tooltip
                  formatter={(val: any) => [`${val}%`, 'Claim Rate']}
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    borderColor: '#e2e8f0',
                    borderRadius: '0.5rem',
                    fontSize: '12px',
                  }}
                />
                <Bar dataKey="claimRate" fill="#6366f1" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 6: Previous Claims vs Claim Rate */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-2">
          <div className="pb-2 border-b border-slate-100">
            <h3 className="text-sm font-semibold text-slate-900">Previous Claims vs Claim Rate</h3>
            <p className="text-xs text-slate-500">
              Claim frequency correlated with recorded past claim history
            </p>
          </div>

          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={prevClaimsData} margin={{ top: 10, right: 10, left: -15, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" tick={{ fontSize: 10, fill: '#64748b' }} />
                <YAxis
                  tick={{ fontSize: 11, fill: '#64748b' }}
                  tickFormatter={(v) => `${v}%`}
                  domain={[0, 'auto']}
                />
                <Tooltip
                  formatter={(val: any) => [`${val}%`, 'Claim Rate']}
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    borderColor: '#e2e8f0',
                    borderRadius: '0.5rem',
                    fontSize: '12px',
                  }}
                />
                <Bar dataKey="claimRate" fill="#f43f5e" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Dynamic Insights Preview Section */}
      {insights.length > 0 && (
        <div className="bg-slate-50 p-5 rounded-xl border border-slate-200/80 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-cyan-600" />
              <h3 className="text-sm font-semibold text-slate-900">
                Key Dynamic Portfolio Insights
              </h3>
            </div>
            <button
              onClick={onNavigateToPerformance}
              className="text-xs text-cyan-700 hover:text-cyan-800 font-semibold"
            >
              See all insights &rarr;
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {insights.map((ins, i) => (
              <div key={i} className="p-3.5 bg-white rounded-lg border border-slate-200 shadow-xs space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-900">{ins.title}</span>
                  <span className="text-[10px] font-semibold text-cyan-700 bg-cyan-50 px-2 py-0.5 rounded-full border border-cyan-100">
                    {ins.highlight}
                  </span>
                </div>
                <p className="text-xs text-slate-500 leading-relaxed">{ins.description}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
