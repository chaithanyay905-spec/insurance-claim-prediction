import React, { useState, useMemo } from 'react';
import { TrainingContext } from '../ml/modelTraining';
import { DatasetStats, ClassificationMetrics } from '../types';
import { ModelMetricsTable } from '../components/ModelMetricsTable';
import { ConfusionMatrix } from '../components/ConfusionMatrix';
import { ThresholdSlider } from '../components/ThresholdSlider';
import { FeatureImportanceChart } from '../components/FeatureImportanceChart';
import { ProbabilityDistributionChart } from '../components/ProbabilityDistributionChart';
import { evaluatePredictions } from '../ml/metrics';
import { generateDynamicInsights } from '../utils/insights';
import {
  GitCompare,
  Sparkles,
  Award,
  Layers,
  CheckCircle2,
  Database,
  Sliders,
  TrendingUp,
  Info,
} from 'lucide-react';

interface ModelPerformanceProps {
  trainingContext: TrainingContext;
  stats: DatasetStats;
}

export const ModelPerformance: React.FC<ModelPerformanceProps> = ({
  trainingContext,
  stats,
}) => {
  const [activeModelForMatrix, setActiveModelForMatrix] = useState<'Random Forest' | 'Logistic Regression'>(
    trainingContext.bestModelName
  );
  const [threshold, setThreshold] = useState<number>(0.5);

  // Selected model data
  const selectedModelData =
    activeModelForMatrix === 'Random Forest'
      ? trainingContext.randomForest
      : trainingContext.logisticRegression;

  // Dynamically recompute metrics on test set when threshold changes
  const dynamicMetrics: ClassificationMetrics = useMemo(() => {
    return evaluatePredictions(
      selectedModelData.testActuals,
      selectedModelData.testProbabilities,
      threshold
    );
  }, [selectedModelData, threshold]);

  const insights = useMemo(() => {
    return generateDynamicInsights(stats, trainingContext);
  }, [stats, trainingContext]);

  return (
    <div id="model-performance-page" className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2">
            <GitCompare className="w-5 h-5 text-cyan-700" />
            <h2 className="text-xl font-bold tracking-tight text-slate-900">
              Model Performance & Evaluation
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-500">
            Comparative analysis of Logistic Regression and Random Forest on independent test records
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="px-3 py-1 bg-cyan-50 border border-cyan-200 text-cyan-900 rounded-full text-xs font-semibold">
            {trainingContext.trainSize} Train / {trainingContext.testSize} Test Partition
          </div>
        </div>
      </div>

      {/* Dataset & Training Specs Grid (Section 12) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="p-3 bg-white rounded-lg border border-slate-200 shadow-xs">
          <div className="text-[11px] font-medium text-slate-500">Training Partition</div>
          <div className="text-base font-bold text-slate-900 mt-0.5">
            {trainingContext.trainSize} (80%)
          </div>
        </div>

        <div className="p-3 bg-white rounded-lg border border-slate-200 shadow-xs">
          <div className="text-[11px] font-medium text-slate-500">Test Partition</div>
          <div className="text-base font-bold text-slate-900 mt-0.5">
            {trainingContext.testSize} (20%)
          </div>
        </div>

        <div className="p-3 bg-white rounded-lg border border-slate-200 shadow-xs">
          <div className="text-[11px] font-medium text-slate-500">Feature Count</div>
          <div className="text-base font-bold text-slate-900 mt-0.5">
            {trainingContext.numFeatures} Variables
          </div>
        </div>

        <div className="p-3 bg-white rounded-lg border border-slate-200 shadow-xs">
          <div className="text-[11px] font-medium text-slate-500">Claim Target</div>
          <div className="text-base font-bold text-slate-900 mt-0.5">0 / 1 Binary</div>
        </div>

        <div className="p-3 bg-white rounded-lg border border-slate-200 shadow-xs">
          <div className="text-[11px] font-medium text-slate-500">Stratified Split</div>
          <div className="text-base font-bold text-emerald-700 mt-0.5">Enforced</div>
        </div>

        <div className="p-3 bg-white rounded-lg border border-slate-200 shadow-xs">
          <div className="text-[11px] font-medium text-slate-500">Model Champion</div>
          <div className="text-base font-bold text-cyan-800 mt-0.5 truncate">
            {trainingContext.bestModelName}
          </div>
        </div>
      </div>

      {/* Section 31 & 33: Side-by-side Model Metrics Table */}
      <ModelMetricsTable
        logisticRegression={trainingContext.logisticRegression}
        randomForest={trainingContext.randomForest}
        bestModelName={trainingContext.bestModelName}
      />

      {/* Model Selector for Detailed Diagnostic Analysis */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-4 bg-slate-50 rounded-xl border border-slate-200/80">
        <div>
          <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
            Diagnostic Inspection Target
          </span>
          <p className="text-xs text-slate-500">
            Select which model to inspect in the confusion matrix and threshold sensitivity views
          </p>
        </div>

        <div className="inline-flex rounded-lg border border-slate-300 p-0.5 bg-white text-xs">
          <button
            onClick={() => setActiveModelForMatrix('Random Forest')}
            className={`px-3 py-1.5 rounded-md font-semibold transition-all ${
              activeModelForMatrix === 'Random Forest'
                ? 'bg-cyan-700 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Random Forest
          </button>
          <button
            onClick={() => setActiveModelForMatrix('Logistic Regression')}
            className={`px-3 py-1.5 rounded-md font-semibold transition-all ${
              activeModelForMatrix === 'Logistic Regression'
                ? 'bg-cyan-700 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Logistic Regression
          </button>
        </div>
      </div>

      {/* Section 36 & Section 32: Threshold Slider & Dynamic Confusion Matrix */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-5 space-y-4">
          <ThresholdSlider
            threshold={threshold}
            onChangeThreshold={setThreshold}
            metrics={dynamicMetrics}
            modelName={activeModelForMatrix}
          />
        </div>

        <div className="lg:col-span-7">
          <ConfusionMatrix
            matrix={dynamicMetrics.confusionMatrix}
            modelName={activeModelForMatrix}
            threshold={threshold}
          />
        </div>
      </div>

      {/* Section 34 & Section 35: Feature Importance & Probability Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <FeatureImportanceChart
          importance={trainingContext.randomForest.featureImportance}
          modelName="Random Forest Classifier"
        />

        <ProbabilityDistributionChart
          probabilities={selectedModelData.testProbabilities}
          modelName={activeModelForMatrix}
        />
      </div>

      {/* Section 37: Dynamic Insights based on actual dataset and model results */}
      <div id="m7x3q8" className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-4">
        <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
          <TrendingUp className="w-4 h-4 text-cyan-700" />
          <h3 className="text-sm font-semibold text-slate-900">
            Dynamically Synthesized Portfolio & Model Insights
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {insights.map((ins, i) => (
            <div
              key={i}
              className="p-4 bg-slate-50/70 rounded-xl border border-slate-200/80 space-y-1.5"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-900">{ins.title}</span>
                <span className="text-[10px] font-semibold text-cyan-800 bg-cyan-100/70 px-2 py-0.5 rounded-full">
                  {ins.highlight}
                </span>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">{ins.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
