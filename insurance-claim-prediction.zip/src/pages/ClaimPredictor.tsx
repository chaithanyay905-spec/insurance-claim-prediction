import React, { useState } from 'react';
import { PredictionInput, PredictionResult as PredictionResultType } from '../types';
import { TrainingContext, predictSingle } from '../ml/modelTraining';
import { ClaimPredictionForm } from '../components/ClaimPredictionForm';
import { PredictionResult } from '../components/PredictionResult';
import { DisclaimerBanner } from '../components/DisclaimerBanner';
import { BrainCircuit, Sparkles, CheckCircle2 } from 'lucide-react';

interface ClaimPredictorProps {
  trainingContext: TrainingContext | null;
  uniquePolicyTypes: string[];
  uniqueVehicleTypes: string[];
  uniqueGenders: string[];
  uniqueVehicleUsages: string[];
  latestPrediction: PredictionResultType | null;
  onSetLatestPrediction: (pred: PredictionResultType) => void;
}

export const ClaimPredictor: React.FC<ClaimPredictorProps> = ({
  trainingContext,
  uniquePolicyTypes,
  uniqueVehicleTypes,
  uniqueGenders,
  uniqueVehicleUsages,
  latestPrediction,
  onSetLatestPrediction,
}) => {
  const [selectedModel, setSelectedModel] = useState<'Logistic Regression' | 'Random Forest'>(
    trainingContext?.bestModelName || 'Random Forest'
  );
  const [isPredicting, setIsPredicting] = useState(false);

  const handlePredict = (input: PredictionInput, model: 'Logistic Regression' | 'Random Forest') => {
    if (!trainingContext) return;
    setIsPredicting(true);

    setTimeout(() => {
      try {
        const result = predictSingle(input, trainingContext, model, 0.5);
        onSetLatestPrediction(result);
      } catch (err) {
        console.error('Prediction failed', err);
      } finally {
        setIsPredicting(false);
      }
    }, 120);
  };

  return (
    <div id="n5x7c2" className="space-y-6 pb-12">
      {/* Header Info */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2">
            <BrainCircuit className="w-5 h-5 text-cyan-700" />
            <h2 className="text-xl font-bold tracking-tight text-slate-900">Claim Predictor</h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-500">
            Estimate individual policy claim probability using trained Logistic Regression or Random Forest classifiers
          </p>
        </div>

        {trainingContext && (
          <div className="flex items-center gap-2 self-start sm:self-auto">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-50 border border-emerald-200 rounded-full text-xs font-semibold text-emerald-800">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              Models Trained ({trainingContext.trainSize} Train / {trainingContext.testSize} Test)
            </span>
          </div>
        )}
      </div>

      {/* Main Grid: Form + Result */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Form */}
        <div className="lg:col-span-7 space-y-4">
          <ClaimPredictionForm
            onPredict={handlePredict}
            uniquePolicyTypes={uniquePolicyTypes}
            uniqueVehicleTypes={uniqueVehicleTypes}
            uniqueGenders={uniqueGenders}
            uniqueVehicleUsages={uniqueVehicleUsages}
            selectedModel={selectedModel}
            onChangeModel={setSelectedModel}
            isPredicting={isPredicting}
          />
        </div>

        {/* Right Column: Prediction Result & Guidance */}
        <div className="lg:col-span-5 space-y-6 lg:sticky lg:top-20">
          {latestPrediction ? (
            <PredictionResult result={latestPrediction} />
          ) : (
            <div className="bg-white rounded-xl border border-dashed border-slate-300 p-8 text-center space-y-3">
              <div className="w-12 h-12 rounded-xl bg-slate-100 flex items-center justify-center text-slate-400 mx-auto">
                <Sparkles className="w-6 h-6" />
              </div>
              <h3 className="text-sm font-semibold text-slate-800">Awaiting Prediction Request</h3>
              <p className="text-xs text-slate-500 leading-relaxed max-w-sm mx-auto">
                Select a sample preset or adjust the policyholder inputs on the left, then click <strong>Predict Claim Likelihood</strong> to evaluate risk.
              </p>
              <DisclaimerBanner compact />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
