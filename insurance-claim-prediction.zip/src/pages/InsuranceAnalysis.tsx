import React, { useState } from 'react';
import { CleanedPolicyRecord, DatasetStats } from '../types';
import { PolicyTable } from '../components/PolicyTable';
import {
  analyzeByAgeGroup,
  analyzeByPolicyType,
  analyzeByVehicleType,
  analyzeByPremiumRange,
  analyzeByPreviousClaims,
  analyzeByAccidentHistory,
  analyzeByVehicleAge,
  analyzeByPolicyTenure,
  analyzePremiumDistribution,
} from '../utils/insuranceAnalysis';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  Legend,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import {
  BarChart3,
  DollarSign,
  Shield,
  Car,
  History,
  Clock,
  User,
  AlertCircle,
  Table as TableIcon,
} from 'lucide-react';

interface InsuranceAnalysisProps {
  records: CleanedPolicyRecord[];
  stats: DatasetStats;
  uniquePolicyTypes: string[];
  uniqueVehicleTypes: string[];
  uniqueGenders: string[];
}

export const InsuranceAnalysis: React.FC<InsuranceAnalysisProps> = ({
  records,
  stats,
  uniquePolicyTypes,
  uniqueVehicleTypes,
  uniqueGenders,
}) => {
  const [activeTab, setActiveTab] = useState<'explorer' | 'charts'>('explorer');

  // Analytical datasets
  const policyTypes = analyzeByPolicyType(records);
  const ageGroups = analyzeByAgeGroup(records);
  const vehicleTypes = analyzeByVehicleType(records);
  const vehicleAges = analyzeByVehicleAge(records);
  const tenureGroups = analyzeByPolicyTenure(records);
  const previousClaims = analyzeByPreviousClaims(records);
  const accidentHistory = analyzeByAccidentHistory(records);
  const premiumDist = analyzePremiumDistribution(records);

  const claimDistData = [
    { name: 'No Claim (0)', value: stats.totalNoClaims, color: '#10b981' },
    { name: 'Claim Filed (1)', value: stats.totalClaims, color: '#ef4444' },
  ];

  return (
    <div id="n6x2c8" className="space-y-6 pb-12">
      {/* Top Header & Overview KPI summary */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-cyan-700" />
            <h2 className="text-xl font-bold tracking-tight text-slate-900">Insurance Analysis</h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-500">
            Comprehensive portfolio demographics, historical claim distributions, and policy explorer
          </p>
        </div>

        {/* View Toggle */}
        <div className="inline-flex rounded-lg border border-slate-300 p-0.5 bg-white text-xs self-start sm:self-auto">
          <button
            onClick={() => setActiveTab('explorer')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-all ${
              activeTab === 'explorer'
                ? 'bg-cyan-700 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <TableIcon className="w-3.5 h-3.5" />
            Policy Explorer
          </button>
          <button
            onClick={() => setActiveTab('charts')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-all ${
              activeTab === 'charts'
                ? 'bg-cyan-700 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            Actuarial Charts
          </button>
        </div>
      </div>

      {/* KPI Stats Strip (Section 18) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2.5">
        <div className="p-3 bg-white rounded-lg border border-slate-200 shadow-xs">
          <div className="text-[11px] font-medium text-slate-500">Total Policies</div>
          <div className="text-base font-bold text-slate-900 mt-0.5">
            {stats.totalPolicies.toLocaleString()}
          </div>
        </div>
        <div className="p-3 bg-white rounded-lg border border-slate-200 shadow-xs">
          <div className="text-[11px] font-medium text-slate-500">Total Claims</div>
          <div className="text-base font-bold text-rose-700 mt-0.5">
            {stats.totalClaims.toLocaleString()}
          </div>
        </div>
        <div className="p-3 bg-white rounded-lg border border-slate-200 shadow-xs">
          <div className="text-[11px] font-medium text-slate-500">No-Claim Policies</div>
          <div className="text-base font-bold text-emerald-700 mt-0.5">
            {stats.totalNoClaims.toLocaleString()}
          </div>
        </div>
        <div className="p-3 bg-white rounded-lg border border-slate-200 shadow-xs">
          <div className="text-[11px] font-medium text-slate-500">Claim Rate</div>
          <div className="text-base font-bold text-slate-900 mt-0.5">{stats.claimRate}%</div>
        </div>
        <div className="p-3 bg-white rounded-lg border border-slate-200 shadow-xs">
          <div className="text-[11px] font-medium text-slate-500">Avg Premium</div>
          <div className="text-base font-bold text-slate-900 mt-0.5">
            ${stats.avgPremium.toLocaleString()}
          </div>
        </div>
        <div className="p-3 bg-white rounded-lg border border-slate-200 shadow-xs">
          <div className="text-[11px] font-medium text-slate-500">Avg Coverage</div>
          <div className="text-base font-bold text-slate-900 mt-0.5">
            ${stats.avgCoverage.toLocaleString()}
          </div>
        </div>
        <div className="p-3 bg-white rounded-lg border border-slate-200 shadow-xs">
          <div className="text-[11px] font-medium text-slate-500">Avg Customer Age</div>
          <div className="text-base font-bold text-slate-900 mt-0.5">{stats.avgCustomerAge} yrs</div>
        </div>
        <div className="p-3 bg-white rounded-lg border border-slate-200 shadow-xs">
          <div className="text-[11px] font-medium text-slate-500">Avg Policy Tenure</div>
          <div className="text-base font-bold text-slate-900 mt-0.5">{stats.avgPolicyTenure} yrs</div>
        </div>
      </div>

      {/* Main Content View */}
      {activeTab === 'explorer' ? (
        <div className="space-y-4">
          <PolicyTable
            records={records}
            stats={stats}
            uniquePolicyTypes={uniquePolicyTypes}
            uniqueVehicleTypes={uniqueVehicleTypes}
            uniqueGenders={uniqueGenders}
          />
        </div>
      ) : (
        <div className="space-y-6">
          {/* Section 21 & Section 25: Claim Rate & Premium Distribution */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Section 21: Claim Rate Analysis */}
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-3">
              <div className="pb-2 border-b border-slate-100">
                <h3 className="text-sm font-semibold text-slate-900">
                  Claim vs No-Claim Distribution
                </h3>
                <p className="text-xs text-slate-500">
                  Total Claims: {stats.totalClaims} ({stats.claimRate}%) • Total No-Claims: {stats.totalNoClaims} ({stats.noClaimRate}%)
                </p>
              </div>

              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={claimDistData}
                      cx="50%"
                      cy="50%"
                      innerRadius={55}
                      outerRadius={80}
                      paddingAngle={4}
                      dataKey="value"
                    >
                      {claimDistData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip
                      formatter={(val: any, name: any) => [`${val} records`, name]}
                      contentStyle={{
                        backgroundColor: '#ffffff',
                        borderColor: '#e2e8f0',
                        borderRadius: '0.5rem',
                        fontSize: '12px',
                      }}
                    />
                    <Legend verticalAlign="bottom" height={36} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Section 25: Premium Analysis */}
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-3">
              <div className="pb-2 border-b border-slate-100">
                <h3 className="text-sm font-semibold text-slate-900">
                  Premium Distribution by Claim Status
                </h3>
                <p className="text-xs text-slate-500">
                  Claim vs No-Claim Average Premium comparison
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-2">
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg">
                  <span className="text-xs text-rose-800 font-medium">Avg Claim Record Premium</span>
                  <div className="text-xl font-bold text-rose-950 mt-1">
                    ${premiumDist.avgClaimPremium.toLocaleString()}
                  </div>
                </div>
                <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg">
                  <span className="text-xs text-emerald-800 font-medium">Avg No-Claim Premium</span>
                  <div className="text-xl font-bold text-emerald-950 mt-1">
                    ${premiumDist.avgNoClaimPremium.toLocaleString()}
                  </div>
                </div>
              </div>

              <div className="h-44 w-full pt-2">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={[
                      { status: 'No Claim (0)', premium: premiumDist.avgNoClaimPremium, fill: '#10b981' },
                      { status: 'Claim (1)', premium: premiumDist.avgClaimPremium, fill: '#ef4444' },
                    ]}
                    margin={{ top: 10, right: 10, left: 10, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis dataKey="status" tick={{ fontSize: 11, fill: '#64748b' }} />
                    <YAxis tick={{ fontSize: 11, fill: '#64748b' }} tickFormatter={(v) => `$${v}`} />
                    <Tooltip
                      formatter={(val: any) => [`$${Number(val).toLocaleString()}`, 'Average Premium']}
                    />
                    <Bar dataKey="premium" radius={[4, 4, 0, 0]}>
                      <Cell fill="#10b981" />
                      <Cell fill="#ef4444" />
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <p className="text-[11px] text-slate-400">
                * Note: Premium variations reflect underwritten coverage tiers, not a causal factor of claims.
              </p>
            </div>
          </div>

          {/* Section 22 & Section 23: Age Analysis & Policy Type Analysis */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Section 22: Age Analysis */}
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-3">
              <div className="pb-2 border-b border-slate-100">
                <h3 className="text-sm font-semibold text-slate-900">Claim Rate by Age Group</h3>
                <p className="text-xs text-slate-500">Observed claim percentages across age cohorts</p>
              </div>

              <div className="h-60 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={ageGroups} margin={{ top: 10, right: 10, left: -10, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis dataKey="name" tick={{ fontSize: 10, fill: '#64748b' }} />
                    <YAxis
                      tick={{ fontSize: 11, fill: '#64748b' }}
                      tickFormatter={(v) => `${v}%`}
                    />
                    <Tooltip
                      formatter={(val: any) => [`${val}%`, 'Claim Rate']}
                      contentStyle={{
                        backgroundColor: '#ffffff',
                        borderColor: '#e2e8f0',
                        borderRadius: '0.5rem',
                        fontSize: '12px',
                      }}
                    />
                    <Bar dataKey="claimRate" fill="#0e7490" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <p className="text-[11px] text-slate-400">
                * Based on actual empirical frequencies. Does not imply age alone causes claim events.
              </p>
            </div>

            {/* Section 23: Policy Type Analysis */}
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-3">
              <div className="pb-2 border-b border-slate-100">
                <h3 className="text-sm font-semibold text-slate-900">
                  Claim Rate by Policy Type
                </h3>
                <p className="text-xs text-slate-500">
                  Relative claim frequency and average premium by coverage tier
                </p>
              </div>

              <div className="h-60 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={policyTypes} margin={{ top: 10, right: 10, left: -10, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis dataKey="name" tick={{ fontSize: 10, fill: '#64748b' }} />
                    <YAxis
                      tick={{ fontSize: 11, fill: '#64748b' }}
                      tickFormatter={(v) => `${v}%`}
                    />
                    <Tooltip
                      formatter={(val: any) => [`${val}%`, 'Claim Rate']}
                      contentStyle={{
                        backgroundColor: '#ffffff',
                        borderColor: '#e2e8f0',
                        borderRadius: '0.5rem',
                        fontSize: '12px',
                      }}
                    />
                    <Bar dataKey="claimRate" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <p className="text-[11px] text-slate-400">
                * Comprehensive and Premium tiers capture broader claim indemnity scopes.
              </p>
            </div>
          </div>

          {/* Section 24, 26, 27, 28, 29: Vehicle, Previous Claims, Accident, Tenure */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Section 26: Previous Claims Analysis */}
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-3">
              <div className="pb-2 border-b border-slate-100">
                <h3 className="text-sm font-semibold text-slate-900">
                  Previous Claims vs Claim Rate
                </h3>
                <p className="text-xs text-slate-500">
                  Correlation between historical past claims and current claim incidence
                </p>
              </div>

              <div className="h-60 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={previousClaims} margin={{ top: 10, right: 10, left: -10, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis dataKey="name" tick={{ fontSize: 10, fill: '#64748b' }} />
                    <YAxis
                      tick={{ fontSize: 11, fill: '#64748b' }}
                      tickFormatter={(v) => `${v}%`}
                    />
                    <Tooltip
                      formatter={(val: any) => [`${val}%`, 'Observed Claim Rate']}
                      contentStyle={{
                        backgroundColor: '#ffffff',
                        borderColor: '#e2e8f0',
                        borderRadius: '0.5rem',
                        fontSize: '12px',
                      }}
                    />
                    <Bar dataKey="claimRate" fill="#f43f5e" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Section 27: Accident History Analysis */}
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-3">
              <div className="pb-2 border-b border-slate-100">
                <h3 className="text-sm font-semibold text-slate-900">
                  Claim Rate by Accident History
                </h3>
                <p className="text-xs text-slate-500">
                  Claim incidence comparing drivers with vs without recorded accident history
                </p>
              </div>

              <div className="h-60 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={accidentHistory} margin={{ top: 10, right: 10, left: -10, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis dataKey="name" tick={{ fontSize: 10, fill: '#64748b' }} />
                    <YAxis
                      tick={{ fontSize: 11, fill: '#64748b' }}
                      tickFormatter={(v) => `${v}%`}
                    />
                    <Tooltip
                      formatter={(val: any) => [`${val}%`, 'Claim Rate']}
                      contentStyle={{
                        backgroundColor: '#ffffff',
                        borderColor: '#e2e8f0',
                        borderRadius: '0.5rem',
                        fontSize: '12px',
                      }}
                    />
                    <Bar dataKey="claimRate" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Section 28: Vehicle Age Analysis */}
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-3">
              <div className="pb-2 border-b border-slate-100">
                <h3 className="text-sm font-semibold text-slate-900">
                  Claim Rate by Vehicle Age
                </h3>
                <p className="text-xs text-slate-500">
                  Comparison across vehicle age cohorts (New vs Moderately Used vs Older)
                </p>
              </div>

              <div className="h-60 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={vehicleAges} margin={{ top: 10, right: 10, left: -10, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis dataKey="name" tick={{ fontSize: 10, fill: '#64748b' }} />
                    <YAxis
                      tick={{ fontSize: 11, fill: '#64748b' }}
                      tickFormatter={(v) => `${v}%`}
                    />
                    <Tooltip
                      formatter={(val: any) => [`${val}%`, 'Claim Rate']}
                      contentStyle={{
                        backgroundColor: '#ffffff',
                        borderColor: '#e2e8f0',
                        borderRadius: '0.5rem',
                        fontSize: '12px',
                      }}
                    />
                    <Bar dataKey="claimRate" fill="#0284c7" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Section 29: Policy Tenure Analysis */}
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-3">
              <div className="pb-2 border-b border-slate-100">
                <h3 className="text-sm font-semibold text-slate-900">
                  Claim Rate by Policy Tenure
                </h3>
                <p className="text-xs text-slate-500">
                  Claim rate trends across customer relationship longevity
                </p>
              </div>

              <div className="h-60 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={tenureGroups} margin={{ top: 10, right: 10, left: -10, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis dataKey="name" tick={{ fontSize: 10, fill: '#64748b' }} />
                    <YAxis
                      tick={{ fontSize: 11, fill: '#64748b' }}
                      tickFormatter={(v) => `${v}%`}
                    />
                    <Tooltip
                      formatter={(val: any) => [`${val}%`, 'Claim Rate']}
                      contentStyle={{
                        backgroundColor: '#ffffff',
                        borderColor: '#e2e8f0',
                        borderRadius: '0.5rem',
                        fontSize: '12px',
                      }}
                    />
                    <Bar dataKey="claimRate" fill="#14b8a6" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
