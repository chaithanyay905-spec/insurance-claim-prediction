import React, { useState, useEffect } from 'react';
import { PageId, Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { Dashboard } from './pages/Dashboard';
import { ClaimPredictor } from './pages/ClaimPredictor';
import { InsuranceAnalysis } from './pages/InsuranceAnalysis';
import { ModelPerformance } from './pages/ModelPerformance';
import { loadAndPreprocessInsuranceData, PreprocessingResult } from './ml/preprocessing';
import { trainModels, TrainingContext } from './ml/modelTraining';
import { computeDatasetStats } from './utils/insuranceAnalysis';
import { generatePdfReport } from './utils/reportGenerator';
import { CleanedPolicyRecord, DatasetStats, PredictionResult } from './types';
import { Loader2, AlertCircle, RefreshCw, CheckCircle2 } from 'lucide-react';

export default function App() {
  const [activePage, setActivePage] = useState<PageId>('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // Data & ML State
  const [loading, setLoading] = useState(true);
  const [loadingStep, setLoadingStep] = useState<string>('Loading insurance records CSV...');
  const [error, setError] = useState<string | null>(null);

  const [records, setRecords] = useState<CleanedPolicyRecord[]>([]);
  const [stats, setStats] = useState<DatasetStats>({
    totalPolicies: 0,
    totalClaims: 0,
    totalNoClaims: 0,
    claimRate: 0,
    noClaimRate: 0,
    avgPremium: 0,
    avgCoverage: 0,
    avgCustomerAge: 0,
    avgPolicyTenure: 0,
    avgDrivingExperience: 0,
    avgVehicleAge: 0,
  });

  const [uniquePolicyTypes, setUniquePolicyTypes] = useState<string[]>([]);
  const [uniqueVehicleTypes, setUniqueVehicleTypes] = useState<string[]>([]);
  const [uniqueGenders, setUniqueGenders] = useState<string[]>([]);
  const [uniqueVehicleUsages, setUniqueVehicleUsages] = useState<string[]>([]);

  const [trainingContext, setTrainingContext] = useState<TrainingContext | null>(null);
  const [latestPrediction, setLatestPrediction] = useState<PredictionResult | null>(null);

  // PDF Generation State & Toasts
  const [isGeneratingReport, setIsGeneratingReport] = useState(false);
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  const initDataAndModels = async () => {
    try {
      setLoading(true);
      setError(null);

      setLoadingStep('Parsing & validating insurance_claims.csv...');
      const prepResult: PreprocessingResult = await loadAndPreprocessInsuranceData(
        '/data/insurance_claims.csv'
      );

      if (prepResult.records.length === 0) {
        throw new Error('Dataset parsed 0 valid policy records. Please verify CSV content.');
      }

      setRecords(prepResult.records);
      setUniquePolicyTypes(prepResult.uniquePolicyTypes);
      setUniqueVehicleTypes(prepResult.uniqueVehicleTypes);
      setUniqueGenders(prepResult.uniqueGenders);
      setUniqueVehicleUsages(prepResult.uniqueVehicleUsages);

      setLoadingStep('Computing dataset distributions & actuarial aggregates...');
      const datasetStats = computeDatasetStats(prepResult.records);
      setStats(datasetStats);

      setLoadingStep('Training Logistic Regression & Random Forest classifiers...');
      // Execute in microtask/setTimeout to give browser UI thread time to render progress
      setTimeout(() => {
        try {
          const context = trainModels(
            prepResult.records,
            prepResult.uniquePolicyTypes,
            prepResult.uniqueVehicleTypes,
            prepResult.uniqueGenders,
            prepResult.uniqueVehicleUsages
          );

          setTrainingContext(context);
          setLoading(false);
        } catch (trainErr: any) {
          console.error('Model training failed', trainErr);
          setError('Model training failed: ' + (trainErr.message || 'Unknown error'));
          setLoading(false);
        }
      }, 50);
    } catch (err: any) {
      console.error('Initialization error', err);
      setError(err.message || 'Failed to load insurance dataset.');
      setLoading(false);
    }
  };

  useEffect(() => {
    initDataAndModels();
  }, []);

  const handleDownloadReport = async () => {
    if (!trainingContext) return;
    try {
      setIsGeneratingReport(true);
      await generatePdfReport(stats, trainingContext, latestPrediction);
      showToast('Insurance Analytics PDF Report generated and downloaded successfully!');
    } catch (err) {
      console.error('PDF generation error', err);
      showToast('Unable to generate the report. Please try again.', 'error');
    } finally {
      setIsGeneratingReport(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 font-sans flex antialiased">
      {/* Sidebar navigation */}
      <Sidebar
        activePage={activePage}
        onSelectPage={setActivePage}
        isOpen={isSidebarOpen}
        onCloseMobile={() => setIsSidebarOpen(false)}
        datasetLoaded={records.length > 0}
        totalPolicies={records.length}
        bestModelName={trainingContext?.bestModelName || ''}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 lg:pl-72">
        {/* Sticky Header */}
        <Header
          onToggleSidebar={() => setIsSidebarOpen((prev) => !prev)}
          datasetLoaded={records.length > 0}
          modelTrained={trainingContext !== null}
          bestModelName={trainingContext?.bestModelName || ''}
          stats={stats}
          onDownloadReport={handleDownloadReport}
          isGeneratingReport={isGeneratingReport}
        />

        {/* Notification Toast */}
        {toastMessage && (
          <div
            className={`fixed bottom-5 right-5 z-50 px-4 py-3 rounded-xl shadow-lg border text-xs sm:text-sm font-semibold flex items-center gap-2.5 transition-all ${
              toastMessage.type === 'success'
                ? 'bg-emerald-900 text-white border-emerald-700'
                : 'bg-rose-900 text-white border-rose-700'
            }`}
          >
            {toastMessage.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-300" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-300" />
            )}
            <span>{toastMessage.text}</span>
          </div>
        )}

        {/* Page Body */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto min-w-0">
          {loading ? (
            <div className="h-[60vh] flex flex-col items-center justify-center space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-cyan-100 flex items-center justify-center text-cyan-800">
                <Loader2 className="w-6 h-6 animate-spin" />
              </div>
              <div className="text-center space-y-1">
                <h3 className="text-base font-semibold text-slate-800">
                  Bootstrapping Machine Learning Engine
                </h3>
                <p className="text-xs sm:text-sm text-slate-500 font-medium">{loadingStep}</p>
              </div>
              <div className="w-64 h-1.5 bg-slate-200 rounded-full overflow-hidden">
                <div className="w-2/3 h-full bg-cyan-700 rounded-full animate-pulse" />
              </div>
            </div>
          ) : error ? (
            <div className="h-[60vh] flex flex-col items-center justify-center space-y-4 max-w-md mx-auto text-center">
              <div className="w-12 h-12 rounded-2xl bg-rose-100 flex items-center justify-center text-rose-700">
                <AlertCircle className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-slate-900">Application Initialization Error</h3>
              <p className="text-xs sm:text-sm text-slate-600">{error}</p>
              <button
                onClick={initDataAndModels}
                className="inline-flex items-center gap-2 px-4 py-2 bg-cyan-700 hover:bg-cyan-800 text-white text-xs sm:text-sm font-semibold rounded-lg transition-colors"
              >
                <RefreshCw className="w-4 h-4" />
                Retry Initialization
              </button>
            </div>
          ) : (
            <>
              {activePage === 'dashboard' && (
                <Dashboard
                  records={records}
                  stats={stats}
                  trainingContext={trainingContext}
                  onNavigateToPredictor={() => setActivePage('predictor')}
                  onNavigateToAnalysis={() => setActivePage('analysis')}
                  onNavigateToPerformance={() => setActivePage('performance')}
                />
              )}

              {activePage === 'predictor' && (
                <ClaimPredictor
                  trainingContext={trainingContext}
                  uniquePolicyTypes={uniquePolicyTypes}
                  uniqueVehicleTypes={uniqueVehicleTypes}
                  uniqueGenders={uniqueGenders}
                  uniqueVehicleUsages={uniqueVehicleUsages}
                  latestPrediction={latestPrediction}
                  onSetLatestPrediction={setLatestPrediction}
                />
              )}

              {activePage === 'analysis' && (
                <InsuranceAnalysis
                  records={records}
                  stats={stats}
                  uniquePolicyTypes={uniquePolicyTypes}
                  uniqueVehicleTypes={uniqueVehicleTypes}
                  uniqueGenders={uniqueGenders}
                />
              )}

              {activePage === 'performance' && trainingContext && (
                <ModelPerformance
                  trainingContext={trainingContext}
                  stats={stats}
                />
              )}
            </>
          )}
        </main>
      </div>
    </div>
  );
}
